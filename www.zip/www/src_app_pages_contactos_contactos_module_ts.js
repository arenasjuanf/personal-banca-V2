"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_contactos_contactos_module_ts"],{

/***/ 40724:
/*!*************************************************************!*\
  !*** ./src/app/pages/contactos/contactos-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactosPageRoutingModule": () => (/* binding */ ContactosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _contactos_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contactos.page */ 65791);




const routes = [
    {
        path: '',
        component: _contactos_page__WEBPACK_IMPORTED_MODULE_0__.ContactosPage
    }
];
let ContactosPageRoutingModule = class ContactosPageRoutingModule {
};
ContactosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ContactosPageRoutingModule);



/***/ }),

/***/ 8579:
/*!*****************************************************!*\
  !*** ./src/app/pages/contactos/contactos.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactosPageModule": () => (/* binding */ ContactosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _contactos_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contactos-routing.module */ 40724);
/* harmony import */ var _contactos_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contactos.page */ 65791);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);








let ContactosPageModule = class ContactosPageModule {
};
ContactosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _contactos_routing_module__WEBPACK_IMPORTED_MODULE_0__.ContactosPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_contactos_page__WEBPACK_IMPORTED_MODULE_1__.ContactosPage]
    })
], ContactosPageModule);



/***/ }),

/***/ 65791:
/*!***************************************************!*\
  !*** ./src/app/pages/contactos/contactos.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactosPage": () => (/* binding */ ContactosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _contactos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contactos.page.html?ngResource */ 52748);
/* harmony import */ var _contactos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contactos.page.scss?ngResource */ 96057);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_contacts_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/contacts.service */ 30407);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/storage.service */ 71188);
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ 84465);









let ContactosPage = class ContactosPage {
    constructor(contactosSVc, storage, alertController, loading, toast) {
        this.contactosSVc = contactosSVc;
        this.storage = storage;
        this.alertController = alertController;
        this.loading = loading;
        this.toast = toast;
        this.initHeaderOptions();
        this.traerContactos();
    }
    ngOnInit() {
    }
    traerContactos() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            this.contactosSVc.getContacts(userId).subscribe((contactos) => {
                this.listaContactos = contactos;
            });
        });
    }
    initHeaderOptions() {
        this.headerOptions = {
            endIcon: 'add',
            endFunction: () => this.searchContact()
        };
    }
    searchContact() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Agregar Contacto',
                inputs: [
                    {
                        name: 'email',
                        type: 'email',
                        placeholder: 'Correo de contacto'
                    }
                ],
                buttons: [{
                        text: 'Aceptar',
                        handler: ({ email }) => (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
                            if (!email) {
                                return;
                            }
                            if (!(yield this.validarEmail(email))) {
                                this.toast.show({
                                    message: 'Contacto ya existe',
                                    icon: 'close',
                                    duration: 1500,
                                    position: 'bottom'
                                });
                                return;
                            }
                            this.loading.show('Agregando contacto');
                            (yield this.contactosSVc.addContact(email.toLowerCase())).subscribe(({ success, msj }) => {
                                this.loading.hide();
                                if (success) {
                                    this.traerContactos();
                                }
                                this.toast.show({
                                    message: msj,
                                    icon: success ? 'checkmark' : 'close',
                                    duration: 1500,
                                    position: 'bottom'
                                });
                            });
                        })
                    },
                    {
                        role: 'cancel', text: 'Cancelar'
                    }]
            });
            yield alert.present();
        });
    }
    validarEmail(email) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const { email: userEmail } = yield this.storage.get('user');
            const [contactExists] = this.listaContactos.filter((contact) => contact.email === email);
            return (email !== userEmail && !contactExists);
        });
    }
    ;
};
ContactosPage.ctorParameters = () => [
    { type: src_app_services_contacts_service__WEBPACK_IMPORTED_MODULE_2__.ContactsService },
    { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_4__.StorageService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.AlertController },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__.LoadingService },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService }
];
ContactosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-contactos',
        template: _contactos_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_contactos_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ContactosPage);



/***/ }),

/***/ 96057:
/*!****************************************************************!*\
  !*** ./src/app/pages/contactos/contactos.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".item {\n  border-radius: 10px;\n  border: 4px solid #5a74f836;\n  margin: 2px;\n  background-color: #6fa1f50a;\n}\n\nion-content::part(background) {\n  border: 2px solid #b9cae833;\n  margin: 4px;\n  border-radius: 20px;\n  background-color: #e3edff33;\n}\n\nion-list {\n  background: none;\n  padding: 10px 6px 6px 6px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbnRhY3Rvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFSSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLDJCQUFBO0FBQUo7O0FBS0E7RUFDSSwyQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0FBRko7O0FBS0E7RUFDSSxnQkFBQTtFQUNBLHlCQUFBO0FBRkoiLCJmaWxlIjoiY29udGFjdG9zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5pdGVte1xyXG4gICAgLy8gYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uLy4uLy4uL2Fzc2V0cy9jaXJjbGVzLnN2Zyk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYm9yZGVyOiA0cHggc29saWQgIzVhNzRmODM2O1xyXG4gICAgbWFyZ2luOiAycHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNmZhMWY1MGE7XHJcbn1cclxuXHJcblxyXG5cclxuaW9uLWNvbnRlbnQ6OnBhcnQoYmFja2dyb3VuZCl7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjYjljYWU4MzM7XHJcbiAgICBtYXJnaW46IDRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTNlZGZmMzM7XHJcbn1cclxuXHJcbmlvbi1saXN0e1xyXG4gICAgYmFja2dyb3VuZDogbm9uZTtcclxuICAgIHBhZGRpbmc6IDEwcHggNnB4IDZweCA2cHg7XHJcbn0iXX0= */";

/***/ }),

/***/ 52748:
/*!****************************************************************!*\
  !*** ./src/app/pages/contactos/contactos.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"Contactos\" [datos]=\"headerOptions\"></app-header>\n\n<ion-content>\n  <ion-list lines=\"none\">\n\n\n    <ion-item-sliding *ngFor=\"let contact of listaContactos\">\n      <ion-item>\n        <ion-label> {{ contact.nombre | titlecase }} </ion-label>\n        <ion-label slot=\"end\">\n          <small> {{ contact.email }} </small>\n        </ion-label>\n      </ion-item>\n\n\n      <ion-item-options side=\"end\">\n        <ion-item-option color=\"none\">\n          <ion-button color=\"none\">\n            <ion-icon name=\"trash\" color=\"danger\"></ion-icon>\n          </ion-button>\n        </ion-item-option>\n      </ion-item-options>\n\n    </ion-item-sliding>\n\n\n   \n  </ion-list>\n</ion-content>\n\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_contactos_contactos_module_ts.js.map