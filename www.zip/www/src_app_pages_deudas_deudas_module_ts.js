"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_deudas_deudas_module_ts"],{

/***/ 63011:
/*!***************************************!*\
  !*** ./src/app/models/deuda.model.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeudaModel": () => (/* binding */ DeudaModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);

/* eslint-disable @typescript-eslint/naming-convention */

class DeudaModel {
    constructor() {
        this.tipo = 2; // 1 ahorro | 2 deuda
        this.requiereFecha = false;
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], DeudaModel.prototype, "tipo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], DeudaModel.prototype, "nombre", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' }),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.numeric)({ message: 'debe ingresar un número' })
], DeudaModel.prototype, "objetivo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.numeric)({ message: 'debe ingresar un número' })
], DeudaModel.prototype, "ahorrado", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], DeudaModel.prototype, "requiereFecha", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], DeudaModel.prototype, "fechaMeta", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], DeudaModel.prototype, "id", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], DeudaModel.prototype, "fk_id_usuario", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], DeudaModel.prototype, "created_at", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], DeudaModel.prototype, "updated_at", void 0);


/***/ }),

/***/ 15235:
/*!*******************************************************!*\
  !*** ./src/app/pages/deudas/deudas-routing.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeudasPageRoutingModule": () => (/* binding */ DeudasPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _deudas_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deudas.page */ 39853);




const routes = [
    {
        path: '',
        component: _deudas_page__WEBPACK_IMPORTED_MODULE_0__.DeudasPage
    }
];
let DeudasPageRoutingModule = class DeudasPageRoutingModule {
};
DeudasPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DeudasPageRoutingModule);



/***/ }),

/***/ 98325:
/*!***********************************************!*\
  !*** ./src/app/pages/deudas/deudas.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeudasPageModule": () => (/* binding */ DeudasPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _deudas_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deudas-routing.module */ 15235);
/* harmony import */ var _deudas_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./deudas.page */ 39853);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);
/* harmony import */ var _vista_vista_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./vista/vista.component */ 90584);
/* harmony import */ var _form_form_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./form/form.component */ 35127);











let DeudasPageModule = class DeudasPageModule {
};
DeudasPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _deudas_routing_module__WEBPACK_IMPORTED_MODULE_0__.DeudasPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_10__.RxReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule
        ],
        declarations: [_deudas_page__WEBPACK_IMPORTED_MODULE_1__.DeudasPage, _form_form_component__WEBPACK_IMPORTED_MODULE_4__.FormComponent, _vista_vista_component__WEBPACK_IMPORTED_MODULE_3__.VistaComponent]
    })
], DeudasPageModule);



/***/ }),

/***/ 39853:
/*!*********************************************!*\
  !*** ./src/app/pages/deudas/deudas.page.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeudasPage": () => (/* binding */ DeudasPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _deudas_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deudas.page.html?ngResource */ 36727);
/* harmony import */ var _deudas_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./deudas.page.scss?ngResource */ 79985);
/* harmony import */ var _ahorros_ahorros_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./../ahorros/ahorros.page.scss?ngResource */ 37698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/ahorros.service */ 58680);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_shared_globals__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/globals */ 19432);
/* harmony import */ var _form_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./form/form.component */ 35127);
/* harmony import */ var _vista_vista_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./vista/vista.component */ 90584);












let DeudasPage = class DeudasPage {
    constructor(deudas, modalCtrol, routerOutlet, loading, alert, aRoute) {
        this.deudas = deudas;
        this.modalCtrol = modalCtrol;
        this.routerOutlet = routerOutlet;
        this.loading = loading;
        this.alert = alert;
        this.aRoute = aRoute;
        this.getTipoAhorro = src_app_shared_globals__WEBPACK_IMPORTED_MODULE_5__.Globals.getTipoAhorro;
        this.initHeaderOptions();
        this.loading.show('Cargando deudas');
        this.getDeudas();
        this.aRoute.params.subscribe((params) => {
            if (params.create) {
                this.openModalForm();
            }
        });
    }
    ngOnInit() {
    }
    getDeudas() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.deudas.getAll(2)).subscribe((list) => {
                this.list = list;
                this.loading.hide();
            });
        });
    }
    initHeaderOptions() {
        this.headerOptions = {
            endIcon: 'add',
            endFunction: () => this.openModalForm()
        };
    }
    openModalForm(deudaEdit) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrol.create({
                animated: true,
                mode: 'md',
                component: _form_form_component__WEBPACK_IMPORTED_MODULE_6__.FormComponent,
                swipeToClose: false,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: deudaEdit ? { deudaEdit } : null
            });
            yield modal.present();
            const { update } = (yield modal.onDidDismiss()).data || {};
            if (update) {
                this.loading.show('Cargando deudas');
                this.getDeudas();
            }
        });
    }
    openModalView(ahorro) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrol.create({
                animated: true,
                mode: 'md',
                component: _vista_vista_component__WEBPACK_IMPORTED_MODULE_7__.VistaComponent,
                swipeToClose: false,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: { ahorro }
            });
            yield modal.present();
            const { data } = (yield modal.onDidDismiss());
            if (data === null || data === void 0 ? void 0 : data.update) {
                this.loading.show('Cargando ahorros');
                this.getDeudas();
            }
        });
    }
    alertDelete(deuda) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                header: 'Eliminar',
                message: 'Está seguro de eliminar la deuda?',
                buttons: [{
                        text: 'Si',
                        handler: (result) => {
                            this.delete(deuda);
                        }
                    },
                    {
                        role: 'cancel', text: 'No'
                    }]
            });
            return yield alert.present();
        });
    }
    delete(ahorro) {
        this.loading.show('Eliminando Deuda');
        this.deudas.delete(ahorro.id, ahorro.tipo).subscribe(({ success }) => {
            if (success) {
                this.getDeudas();
            }
        });
    }
    openModalEdit(deuda) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.openModalForm(deuda);
        });
    }
};
DeudasPage.ctorParameters = () => [
    { type: src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_3__.AhorrosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonRouterOutlet },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__.LoadingService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute }
];
DeudasPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-deudas',
        template: _deudas_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_deudas_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__, _ahorros_ahorros_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_2__]
    })
], DeudasPage);



/***/ }),

/***/ 35127:
/*!*****************************************************!*\
  !*** ./src/app/pages/deudas/form/form.component.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormComponent": () => (/* binding */ FormComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _form_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form.component.html?ngResource */ 14975);
/* harmony import */ var _ahorros_form_form_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ahorros/form/form.component.scss?ngResource */ 33554);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_components_calendar_calendar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/calendar/calendar.component */ 33373);
/* harmony import */ var src_app_models_deuda_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/models/deuda.model */ 63011);
/* harmony import */ var src_app_services_deudas_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/deudas.service */ 20115);
/* harmony import */ var src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/forms.service */ 76311);
/* harmony import */ var src_app_shared_globals__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/globals */ 19432);











let FormComponent = class FormComponent {
    constructor(modalCtrl, popoverCtrl, formService, deudasService) {
        this.modalCtrl = modalCtrl;
        this.popoverCtrl = popoverCtrl;
        this.formService = formService;
        this.deudasService = deudasService;
        this.tiposAhorro = src_app_shared_globals__WEBPACK_IMPORTED_MODULE_6__.Globals.tiposAhorro;
        this.form = this.formService.initForm(new src_app_models_deuda_model__WEBPACK_IMPORTED_MODULE_3__.DeudaModel());
        this.form.get('requiereFecha').valueChanges.subscribe((value) => {
            if (value) {
                this.form.get('fechaMeta').clearValidators();
            }
            else {
                this.form.get('fechaMeta').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_7__.Validators.required);
            }
            this.form.get('fechaMeta').updateValueAndValidity();
        });
        this.initHeaderOptions();
    }
    ngOnInit() {
        if (this.deudaEdit) {
            this.form.patchValue(this.deudaEdit);
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            !this.deudaEdit.fechaMeta && this.form.get('requiereFecha').setValue(true);
        }
    }
    initHeaderOptions() {
        this.headerOptions = {
            startIcon: '-',
            startFunction: () => { },
            endIcon: 'close',
            endFunction: () => this.modalCtrl.dismiss()
        };
    }
    openDatePicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverCtrl.create({
                component: src_app_components_calendar_calendar_component__WEBPACK_IMPORTED_MODULE_2__.CalendarComponent,
                mode: 'ios',
                backdropDismiss: true,
                showBackdrop: true,
                size: 'auto',
                cssClass: 'pop-date',
            });
            yield popover.present();
            const { date } = (yield popover.onDidDismiss()).data || '';
            this.form.get('fechaMeta').setValue(date);
        });
    }
    save() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            if (this.form.value.requiereFecha) {
                delete this.form.value.fechaMeta;
            }
            (yield this.deudasService.save(this.form.value, this.deudaEdit ? true : false)).subscribe(({ success }) => {
                if (success) {
                    this.modalCtrl.dismiss({ update: true });
                }
            });
        });
    }
};
FormComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.PopoverController },
    { type: src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_5__.FormsService },
    { type: src_app_services_deudas_service__WEBPACK_IMPORTED_MODULE_4__.DeudasService }
];
FormComponent.propDecorators = {
    deudaEdit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input }]
};
FormComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-form',
        template: _form_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ahorros_form_form_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FormComponent);



/***/ }),

/***/ 90584:
/*!*******************************************************!*\
  !*** ./src/app/pages/deudas/vista/vista.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VistaComponent": () => (/* binding */ VistaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _vista_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vista.component.html?ngResource */ 7782);
/* harmony import */ var _ahorros_vista_vista_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ahorros/vista/vista.component.scss?ngResource */ 7258);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_deudas_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/deudas.service */ 20115);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/toast.service */ 84465);








let VistaComponent = class VistaComponent {
    constructor(modalCtrl, deudasService, alertController, loading, toast) {
        this.modalCtrl = modalCtrl;
        this.deudasService = deudasService;
        this.alertController = alertController;
        this.loading = loading;
        this.toast = toast;
        this.update = false;
        this.initHeaderOptions();
    }
    ngOnInit() {
        this.loading.show('Cargando deuda');
        this.getDeuda(this.ahorro.id);
    }
    initHeaderOptions() {
        this.headerOptions = {
            startIcon: '-',
            startFunction: () => { },
            endIcon: 'close',
            endFunction: () => this.modalCtrl.dismiss({ update: this.update })
        };
    }
    getDeuda(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const ahorro = yield this.deudasService.getOne(id);
            ahorro.subscribe((result) => {
                this.datosAhorro = result;
                this.loading.hide();
            });
        });
    }
    showAddMonto() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Cuanto vas a abonar?',
                inputs: [
                    {
                        name: 'valor',
                        type: 'number',
                        placeholder: '$'
                    }
                ],
                buttons: [{
                        text: 'Aceptar',
                        handler: ({ valor }) => {
                            const { objetivo, ahorrado } = this.datosAhorro;
                            if (valor <= (objetivo - ahorrado)) {
                                this.addMonto(valor);
                            }
                            else {
                                this.toast.show({
                                    message: 'El monto ingresado sobrepasa el total de la deuda',
                                    icon: 'close',
                                    duration: 1500,
                                    position: 'bottom'
                                });
                            }
                        }
                    },
                    {
                        role: 'cancel', text: 'Cancelar'
                    }]
            });
            yield alert.present();
        });
    }
    addMonto(valor) {
        const data = {
            monto: +valor,
            idAhorro: this.datosAhorro.id
        };
        this.loading.show(`Agregando abono`);
        this.deudasService.addMonto(data).subscribe(({ success }) => {
            if (success) {
                this.update = true;
                this.getDeuda(this.datosAhorro.id);
            }
        });
    }
};
VistaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: src_app_services_deudas_service__WEBPACK_IMPORTED_MODULE_2__.DeudasService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__.LoadingService },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__.ToastService }
];
VistaComponent.propDecorators = {
    ahorro: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input }]
};
VistaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-vista',
        template: _vista_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ahorros_vista_vista_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], VistaComponent);



/***/ }),

/***/ 20115:
/*!********************************************!*\
  !*** ./src/app/services/deudas.service.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeudasService": () => (/* binding */ DeudasService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _shared_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/utils */ 22134);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./storage.service */ 71188);






let DeudasService = class DeudasService {
    constructor(http, storage) {
        this.http = http;
        this.storage = storage;
    }
    getAll(type = 2) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            return this.http.get(`traerAhorros/${userId}/${type}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((ahorros) => ahorros.map((ahorro) => {
                const { objetivo, ahorrado } = ahorro;
                return Object.assign(Object.assign({}, ahorro), { percent: _shared_utils__WEBPACK_IMPORTED_MODULE_0__.Utils.getPercentage(ahorrado, objetivo) });
            })));
        });
    }
    save(data, update) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            return this.http.post(!update ? 'agregarDeuda' : 'actualizarAhorro', Object.assign(Object.assign({}, data), { 
                // eslint-disable-next-line @typescript-eslint/naming-convention
                fk_id_usuario: userId, nombreAhorro: data.nombre }));
        });
    }
    getOne(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const montos = yield this.http.get(`datosMontos/${id}`).toPromise();
            return this.http.get(`datosAhorro/${id}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((result) => (Object.assign(Object.assign({}, result), { montos }))));
        });
    }
    selectIntervalo(data) {
        return this.http.put(`actualizarMonto`, data);
    }
    addMonto(data) {
        return this.http.post(`agregarMonto`, data);
    }
    delete(idAhorro, tipo) {
        return this.http.delete(`borrarAhorro`, { idAhorro, tipo });
    }
};
DeudasService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_1__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService }
];
DeudasService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], DeudasService);



/***/ }),

/***/ 79985:
/*!**********************************************************!*\
  !*** ./src/app/pages/deudas/deudas.page.scss?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJkZXVkYXMucGFnZS5zY3NzIn0= */";

/***/ }),

/***/ 36727:
/*!**********************************************************!*\
  !*** ./src/app/pages/deudas/deudas.page.html?ngResource ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"Deudas\" [datos]=\"headerOptions\"></app-header>\r\n\r\n<ion-content>\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col size=\"12\" size-md=\"4\" *ngFor=\"let deuda of list\" >\r\n        <ion-card class=\"pointer item\">\r\n          <ion-grid fixed>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-card-header class=\"ion-no-padding\">\r\n                  <ion-text>\r\n                    <h5>\r\n                      {{ deuda.nombre | titlecase }}\r\n                    </h5>\r\n                  </ion-text>\r\n                  <ion-card-subtitle>{{deuda.percent}}%</ion-card-subtitle>\r\n                  <ion-progress-bar value=\"{{deuda.percent/100}}\" ></ion-progress-bar>\r\n                  <ion-card-subtitle class=\"meta-tipo\">                     \r\n                    <span>\r\n                      Valor: {{ deuda.objetivo | currency:\"$\":\"symbol\"  }}\r\n                    </span>                    \r\n                  </ion-card-subtitle>\r\n                  <ion-card-subtitle class=\"meta-tipo\">\r\n                    <span>\r\n                      Falta: {{ (deuda.objetivo - deuda.ahorrado) | currency:\"$\":\"symbol\"  }}\r\n                    </span>\r\n                    <span *ngIf=\"deuda?.fechaMeta\">\r\n                      <small>Fecha Meta: {{ deuda.fechaMeta | date}}</small>\r\n                    </span>\r\n                  </ion-card-subtitle>\r\n                </ion-card-header>\r\n                <ion-card-content class=\"ion-text-end\">\r\n                  <ion-button shape=\"round\" color=\"primary\" (click)=\"openModalView(deuda)\">\r\n                    <ion-icon name=\"eye\"></ion-icon>\r\n                  </ion-button>\r\n                  <ion-button shape=\"round\" color=\"secondary\" (click)=\"openModalEdit(deuda)\">\r\n                    <ion-icon name=\"create\"></ion-icon>\r\n                  </ion-button>\r\n                  <ion-button shape=\"round\" color=\"danger\" (click)=\"alertDelete(deuda)\">\r\n                    <ion-icon name=\"trash\" ></ion-icon>\r\n                  </ion-button>                \r\n                </ion-card-content>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>          \r\n        </ion-card>\r\n      </ion-col>\r\n      <ion-col size=\"12\" *ngIf=\"!list?.length\">\r\n        <ion-card class=\"ion-padding\">\r\n          <ion-card-title class=\"ion-text-center\">\r\n            No tienes deudas\r\n          </ion-card-title>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n";

/***/ }),

/***/ 14975:
/*!******************************************************************!*\
  !*** ./src/app/pages/deudas/form/form.component.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"{{ deudaEdit ? 'Actualizar' : 'Crear' }} Deuda\" [datos]=\"headerOptions\"></app-header>\r\n<ion-content>\r\n  <ion-list lines=\"none\" class=\"ion-no-margin\" [formGroup]=\"form\">\r\n    <ion-item>\r\n      <ion-label position=\"floating\">Nombre</ion-label>\r\n      <ion-input formControlName=\"nombre\"></ion-input>\r\n    </ion-item>\r\n    <ion-item *ngIf=\"!deudaEdit\">\r\n      <ion-label position=\"floating\">Valor Deuda</ion-label>\r\n      <ion-input placeholder=\"¿Cuanto quieres ahorrar?\" formControlName=\"objetivo\" type=\"number\"></ion-input>\r\n    </ion-item>\r\n    <ion-item >\r\n      <ion-label>Sin fecha meta</ion-label>\r\n      <ion-toggle formControlName=\"requiereFecha\"></ion-toggle>\r\n    </ion-item>\r\n    <ion-item *ngIf=\"!form.get('requiereFecha').value\">\r\n      <ion-label position=\"floating\">Fecha Meta</ion-label>\r\n      <ion-input formControlName=\"fechaMeta\" (click)=\"openDatePicker()\" readonly></ion-input>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n\r\n<ion-footer class=\"ion-text-center ion-no-border\" collapse=\"fade\">\r\n  <ion-button color=\"primary\" [disabled]=\"form.invalid\"  (click)=\"save()\" > {{ deudaEdit ? 'Actualizar' : 'Guardar' }} </ion-button>\r\n  <ion-button color=\"danger\" (click)=\"modalCtrl.dismiss()\"> Cancelar </ion-button>\r\n</ion-footer>";

/***/ }),

/***/ 7782:
/*!********************************************************************!*\
  !*** ./src/app/pages/deudas/vista/vista.component.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [title]=\"datosAhorro?.nombre || ''\" [datos]=\"headerOptions\"></app-header>\r\n<ion-content class=\"content\">\r\n  <ion-card>\r\n    <ion-card-content>\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col [size]=\"datosAhorro?.tipo_ahorro === 1 ? 9 : 12\">\r\n            <ion-row>\r\n              <ion-col size=\"12\" class=\"objetivo\">\r\n                <ion-text >\r\n                  <h4>\r\n                    Objetivo: {{ datosAhorro?.objetivo | currency:\"$\":\"symbol\"}}\r\n                  </h4>\r\n                </ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-text >\r\n                  <h4>Ahorrado: {{ (datosAhorro?.ahorrado) | currency:\"$\":\"symbol\" }}</h4>\r\n                </ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-col>\r\n          <ion-col size=\"3\" class=\"ion-text-end btn-add-container \" >\r\n            <ion-button fill=\"solid\" color=\"primary\" size=\"small\" (click)=\"showAddMonto()\">\r\n              <ion-icon name=\"add\"></ion-icon>\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n  <ion-card>\r\n    <ion-list lines=\"full\" >\r\n      <ion-item-sliding *ngFor=\"let monto of datosAhorro?.montos || []\">\r\n        <ion-item>\r\n          <ion-label slot=\"start\">{{ monto.valor | currency:\"$\":\"symbol\" }}</ion-label>     \r\n          <ion-label slot=\"end\">{{ monto.created_at | date}}</ion-label>        \r\n        </ion-item>\r\n        <ion-item-options side=\"end\">\r\n          <ion-item-option>\r\n            <ion-icon name=\"help-circle-outline\"></ion-icon>\r\n          </ion-item-option>\r\n        </ion-item-options>\r\n      </ion-item-sliding>\r\n      <ion-item *ngIf=\"!datosAhorro?.montos?.length\" class=\"ion-text-center\">\r\n        <ion-label> No hay montos </ion-label>\r\n      </ion-item>\r\n    </ion-list>\r\n  </ion-card>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_deudas_deudas_module_ts.js.map