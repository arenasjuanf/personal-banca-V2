"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_recover-pass_recover-pass_module_ts"],{

/***/ 68669:
/*!******************************************************************!*\
  !*** ./src/app/auth/recover-pass/recover-pass-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RecoverPassPageRoutingModule": () => (/* binding */ RecoverPassPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _recover_pass_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recover-pass.page */ 28083);




const routes = [
    {
        path: '',
        component: _recover_pass_page__WEBPACK_IMPORTED_MODULE_0__.RecoverPassPage
    }
];
let RecoverPassPageRoutingModule = class RecoverPassPageRoutingModule {
};
RecoverPassPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RecoverPassPageRoutingModule);



/***/ }),

/***/ 86725:
/*!**********************************************************!*\
  !*** ./src/app/auth/recover-pass/recover-pass.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RecoverPassPageModule": () => (/* binding */ RecoverPassPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _recover_pass_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recover-pass-routing.module */ 68669);
/* harmony import */ var _recover_pass_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./recover-pass.page */ 28083);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);








let RecoverPassPageModule = class RecoverPassPageModule {
};
RecoverPassPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _recover_pass_routing_module__WEBPACK_IMPORTED_MODULE_0__.RecoverPassPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_7__.RxReactiveFormsModule
        ],
        declarations: [_recover_pass_page__WEBPACK_IMPORTED_MODULE_1__.RecoverPassPage]
    })
], RecoverPassPageModule);



/***/ }),

/***/ 28083:
/*!********************************************************!*\
  !*** ./src/app/auth/recover-pass/recover-pass.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RecoverPassPage": () => (/* binding */ RecoverPassPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _recover_pass_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./recover-pass.page.html?ngResource */ 37624);
/* harmony import */ var _recover_pass_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./recover-pass.page.scss?ngResource */ 16483);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/forms.service */ 76311);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/toast.service */ 84465);



/* eslint-disable @typescript-eslint/consistent-type-assertions */
/* eslint-disable max-len */








let RecoverPassPage = class RecoverPassPage {
    constructor(fb, forms, authService, loading, toast, alertController, router) {
        this.fb = fb;
        this.forms = forms;
        this.authService = authService;
        this.loading = loading;
        this.toast = toast;
        this.alertController = alertController;
        this.router = router;
        this.ingresarPin = false;
        this.initForm();
    }
    ngOnInit() {
    }
    initForm() {
        this.form = this.fb.group({
            correo: ['', [_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_6__.RxwebValidators.email({ message: 'Debe ser un correo electrónico válido' }), _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_6__.RxwebValidators.required({ message: 'Campo requerido' })]]
        });
    }
    sendRecoverMail() {
        if (this.form.valid) {
            const { correo } = this.form.value;
            this.loading.show('Enviando mail...');
            this.authService.sendRecoverMail(correo).subscribe((result) => {
                const { success, msj } = result;
                this.loading.hide();
                if (success) {
                    this.toast.show({
                        message: msj,
                        icon: 'checkmark',
                        position: 'bottom',
                        duration: 1500
                    });
                    this.ingresarPin = true;
                }
                else {
                    this.toast.show({
                        message: 'Correo Electrónico no encontrado',
                        icon: 'close',
                        position: 'bottom',
                        duration: 1500
                    });
                }
            }, () => {
                this.loading.hide();
                this.toast.show({
                    message: 'Correo Electrónico no encontrado',
                    icon: 'close',
                    position: 'bottom',
                    duration: 1500
                });
            });
        }
    }
    confirmPin(pin) {
        const { correo: email } = this.form.value;
        this.loading.show('Validando PIN...');
        this.authService.sendRecoverPin(email, pin).subscribe((result) => {
            this.loading.hide();
            const { success } = result;
            this.toast.show({
                message: success ? 'Pin correcto' : 'Pin Incorrecto',
                icon: success ? 'checkmark' : 'close',
                position: 'bottom',
                duration: 1000
            });
            if (success) {
                this.showAlertPassword();
            }
        });
    }
    showAlertPassword() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Ingresa la nueva contraseña',
                inputs: [
                    {
                        name: 'pass',
                        type: 'password',
                        placeholder: 'Nueva Clave'
                    },
                    {
                        name: 'pass2',
                        type: 'password',
                        placeholder: 'Repite Nueva Clave'
                    }
                ],
                buttons: [{
                        text: 'Aceptar',
                        handler: ({ pass, pass2 }) => {
                            if (pass === pass2) {
                                this.loading.show('Asignando nueva contraseña');
                                const { correo: email } = this.form.value;
                                this.authService.setNewPassword(email, pass).subscribe((result) => {
                                    if (result.success) {
                                        this.toast.show({
                                            message: 'Nueva Contraseña asignada correctamente',
                                            icon: 'checkmark',
                                            position: 'bottom',
                                            duration: 1500
                                        });
                                        this.router.navigateByUrl('auth');
                                    }
                                    else {
                                        this.toast.show({
                                            message: 'Error al asignar nueva contraseña',
                                            icon: 'close',
                                            position: 'bottom',
                                            duration: 1500
                                        });
                                    }
                                    this.loading.hide();
                                });
                            }
                            else {
                                this.showAlertPassword();
                            }
                        }
                    },
                    {
                        role: 'cancel', text: 'Cancelar'
                    }]
            });
            yield alert.present();
        });
    }
};
RecoverPassPage.ctorParameters = () => [
    { type: _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_6__.RxFormBuilder },
    { type: src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_3__.FormsService },
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_2__.AuthService },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__.LoadingService },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_5__.ToastService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_9__.Router }
];
RecoverPassPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-recover-pass',
        template: _recover_pass_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_recover_pass_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RecoverPassPage);



/***/ }),

/***/ 16483:
/*!*********************************************************************!*\
  !*** ./src/app/auth/recover-pass/recover-pass.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "ion-grid {\n  font-family: \"Poppins\", sans-serif;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-grid ion-row {\n  height: auto;\n}\nion-grid ion-row ion-img {\n  width: 75%;\n  margin: auto;\n}\nion-grid ion-row h1 {\n  font-weight: 700;\n  margin: 0 0 0 0;\n}\nion-grid ion-row .form-cont {\n  background-color: #ffffff8a;\n  border-radius: 25px;\n  border: 3px solid #b5abab40;\n}\nion-grid ion-row ion-col {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-grid ion-row ion-col .input {\n  border-radius: 20px;\n  border: 1px solid #3780ff9e;\n  margin: 10px 0 0px 0;\n}\nion-grid ion-row ion-col .mantener-sesion {\n  margin-bottom: 10px;\n}\nion-grid ion-row ion-col .mantener-sesion ion-label {\n  margin-left: 10px;\n}\nion-grid ion-row ion-col .mantener-sesion::part(native) {\n  background-color: transparent;\n}\nion-grid ion-row ion-col .recuperar-clave {\n  margin-top: 10px;\n}\nion-grid ion-row ion-col ion-button {\n  border: 3px solid #b5abab12;\n  width: 60%;\n  margin: auto;\n}\nion-content::part(scroll) {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-content::part(background) {\n  background: url('figures2.svg');\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.text-terminos {\n  color: var(--ion-color-primary);\n}\nion-text {\n  display: flex;\n  margin-bottom: 10px;\n  justify-content: space-between;\n}\nion-text h1 {\n  margin-bottom: 0;\n}\nion-text ion-icon {\n  margin: auto 0 auto 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlY292ZXItcGFzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFFSSxrQ0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0FBRko7QUFLSTtFQUNJLFlBQUE7QUFIUjtBQUtRO0VBQ0ksVUFBQTtFQUNBLFlBQUE7QUFIWjtBQU1RO0VBQ0ksZ0JBQUE7RUFDQSxlQUFBO0FBSlo7QUFPUTtFQUNJLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQkFBQTtBQUxaO0FBUVE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQU5aO0FBUVk7RUFDSSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0Esb0JBQUE7QUFOaEI7QUFTWTtFQUlJLG1CQUFBO0FBVmhCO0FBT2dCO0VBQ0ksaUJBQUE7QUFMcEI7QUFTZ0I7RUFDSSw2QkFBQTtBQVBwQjtBQVdZO0VBQ0ksZ0JBQUE7QUFUaEI7QUFZWTtFQUNJLDJCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFWaEI7QUFpQkE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQWRKO0FBaUJBO0VBQ0csK0JBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0FBZEg7QUFpQkE7RUFDSSwrQkFBQTtBQWRKO0FBa0JBO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUFmSjtBQWdCSTtFQUNJLGdCQUFBO0FBZFI7QUFnQkk7RUFDSSxxQkFBQTtBQWRSIiwiZmlsZSI6InJlY292ZXItcGFzcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcbmlvbi1ncmlke1xyXG5cclxuICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWY7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuXHJcbiAgICBpb24tcm93e1xyXG4gICAgICAgIGhlaWdodDogYXV0bztcclxuXHJcbiAgICAgICAgaW9uLWltZ3tcclxuICAgICAgICAgICAgd2lkdGg6IDc1JTtcclxuICAgICAgICAgICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgICAgIH1cclxuICAgIFxyXG4gICAgICAgIGgxe1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgICAgICBtYXJnaW46IDAgMCAwIDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZm9ybS1jb250eyAgICAgICBcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjhhO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDNweCBzb2xpZCAjYjVhYmFiNDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpb24tY29se1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHJcbiAgICAgICAgICAgIC5pbnB1dHtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjMzc4MGZmOWU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDEwcHggMCAwcHggMDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLm1hbnRlbmVyLXNlc2lvbntcclxuICAgICAgICAgICAgICAgIGlvbi1sYWJlbHtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcblxyXG4gICAgICAgICAgICAgICAgJjo6cGFydChuYXRpdmUpe1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAucmVjdXBlcmFyLWNsYXZle1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogM3B4IHNvbGlkICNiNWFiYWIxMjtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA2MCU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IGF1dG87XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcblxyXG5pb24tY29udGVudDo6cGFydChzY3JvbGwpe1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5cclxuaW9uLWNvbnRlbnQ6OnBhcnQoYmFja2dyb3VuZCl7XHJcbiAgIGJhY2tncm91bmQ6IHVybCguLi8uLi8uLi9hc3NldHMvZmlndXJlczIuc3ZnKTtcclxuICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5cclxuLnRleHQtdGVybWlub3N7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpXHJcbn1cclxuXHJcblxyXG5pb24tdGV4dHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgaDF7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgIH1cclxuICAgIGlvbi1pY29ue1xyXG4gICAgICAgIG1hcmdpbjogYXV0byAwIGF1dG8gMDtcclxuICAgIH1cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 37624:
/*!*********************************************************************!*\
  !*** ./src/app/auth/recover-pass/recover-pass.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "\n\n\n<ion-content>\n  <ion-grid class=\"ion-padding\">\n    <ion-row>\n      \n      <ion-col  size-md=\"6\" size-xs=\"12\">\n        <ion-img src=\"./assets/icon/logo.svg\" class=\"ion-padding\"></ion-img>\n      </ion-col>\n\n\n      <ion-col size-md=\"6\" size-xs=\"12\" class=\"ion-padding form-cont\" [formGroup]=\"form\">\n\n        <ion-text class=\"ion-text-center\">\n          <ion-icon size=\"large\" name=\"chevron-back-outline\" class=\"pointer\" routerLink=\"auth\"></ion-icon>\n          <h1>Recupera tu contraseña</h1>\n          <ion-icon name=\"\" ></ion-icon>\n        </ion-text>\n\n        <ng-container *ngIf=\"!ingresarPin\">\n\n          <ion-label>Se enviará un código de recuperación de clave al correo registrado</ion-label>\n\n          <ion-item  class=\"input text-center\" >\n            <ion-input placeholder=\"Ejemplo@personalbanca.com\" formControlName=\"correo\"></ion-input>\n          </ion-item>\n          <ion-note  color=\"danger\">{{ forms.getErrors(form, 'correo')?.required?.message }}</ion-note>  \n          <ion-note  color=\"danger\">{{ forms.getErrors(form, 'correo')?.email?.message }}</ion-note>  \n  \n          <!-- eslint-disable-next-line max-len -->\n          <ion-button color=\"primary\" class=\"login-button ion-activatable ripple-parent\" shape=\"round\" [disabled]=\"form.invalid\" (click)=\"sendRecoverMail()\">\n            <ion-icon name=\"enter-outline\" slot=\"start\"></ion-icon>\n            Enviar correo\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-button>\n\n        </ng-container>\n\n        <ng-container  *ngIf=\"ingresarPin\">\n          <ion-label class=\"text-center\" >Ingresa el pin enviado al correo electrónico </ion-label>\n\n          <ion-item  class=\"input text-center\" >\n            <ion-input type=\"number\" required #pinInput></ion-input>\n          </ion-item>\n          <ion-note  color=\"danger\">{{ forms.getErrors(form, 'correo')?.required?.message }}</ion-note>  \n         \n  \n          <!-- eslint-disable-next-line max-len -->\n          <ion-button color=\"primary\" class=\"login-button ion-activatable ripple-parent\" shape=\"round\" (click)=\"confirmPin(pinInput.value)\">\n            <ion-icon name=\"enter-outline\" slot=\"start\"></ion-icon>\n              Confirmar Pin\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-button>\n\n          <!-- eslint-disable-next-line max-len -->\n          <ion-button color=\"danger\" class=\"login-button ion-activatable ripple-parent\" shape=\"round\" (click)=\"ingresarPin = false\">\n            <ion-icon name=\"enter-outline\" slot=\"start\"></ion-icon>\n              Cancelar\n            <ion-ripple-effect></ion-ripple-effect>\n          </ion-button>\n\n        </ng-container>\n\n\n\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_recover-pass_recover-pass_module_ts.js.map