"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_ahorros_ahorros_module_ts"],{

/***/ 20034:
/*!****************************************!*\
  !*** ./src/app/models/ahorro.model.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AhorroModel": () => (/* binding */ AhorroModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);

/* eslint-disable @typescript-eslint/naming-convention */

class AhorroModel {
    constructor() {
        this.tipo = 1; // 1 ahorro | 2 deuda
        this.requiereFecha = false;
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], AhorroModel.prototype, "tipo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], AhorroModel.prototype, "nombre", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' }),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.numeric)({ message: 'debe ingresar un número' })
], AhorroModel.prototype, "objetivo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.numeric)({ message: 'debe ingresar un número' })
], AhorroModel.prototype, "ahorrado", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido', conditionalExpression: (model) => model.tipo_ahorro === 2 }),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.numeric)({ message: 'debe ingresar un número' })
], AhorroModel.prototype, "intervalo", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' }),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.numeric)({ message: 'debe ingresar un número' })
], AhorroModel.prototype, "tipo_ahorro", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], AhorroModel.prototype, "requiereFecha", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], AhorroModel.prototype, "fechaMeta", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], AhorroModel.prototype, "id", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], AhorroModel.prototype, "fk_id_usuario", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], AhorroModel.prototype, "created_at", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], AhorroModel.prototype, "updated_at", void 0);


/***/ }),

/***/ 31339:
/*!*********************************************************!*\
  !*** ./src/app/pages/ahorros/ahorros-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AhorrosPageRoutingModule": () => (/* binding */ AhorrosPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ahorros_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ahorros.page */ 38374);




const routes = [
    {
        path: '',
        component: _ahorros_page__WEBPACK_IMPORTED_MODULE_0__.AhorrosPage
    }
];
let AhorrosPageRoutingModule = class AhorrosPageRoutingModule {
};
AhorrosPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AhorrosPageRoutingModule);



/***/ }),

/***/ 17590:
/*!*************************************************!*\
  !*** ./src/app/pages/ahorros/ahorros.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AhorrosPageModule": () => (/* binding */ AhorrosPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _ahorros_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ahorros-routing.module */ 31339);
/* harmony import */ var _ahorros_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ahorros.page */ 38374);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);
/* harmony import */ var _form_form_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form/form.component */ 91421);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);
/* harmony import */ var _vista_vista_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./vista/vista.component */ 70517);











let AhorrosPageModule = class AhorrosPageModule {
};
AhorrosPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_7__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonicModule,
            _ahorros_routing_module__WEBPACK_IMPORTED_MODULE_0__.AhorrosPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
            _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_10__.RxReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.FormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_8__.ReactiveFormsModule,
        ],
        declarations: [_ahorros_page__WEBPACK_IMPORTED_MODULE_1__.AhorrosPage, _form_form_component__WEBPACK_IMPORTED_MODULE_3__.FormComponent, _vista_vista_component__WEBPACK_IMPORTED_MODULE_4__.VistaComponent]
    })
], AhorrosPageModule);



/***/ }),

/***/ 38374:
/*!***********************************************!*\
  !*** ./src/app/pages/ahorros/ahorros.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AhorrosPage": () => (/* binding */ AhorrosPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _ahorros_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ahorros.page.html?ngResource */ 59822);
/* harmony import */ var _ahorros_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ahorros.page.scss?ngResource */ 37698);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/ahorros.service */ 58680);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/toast.service */ 84465);
/* harmony import */ var src_app_shared_globals__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/globals */ 19432);
/* harmony import */ var _form_form_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./form/form.component */ 91421);
/* harmony import */ var _vista_vista_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./vista/vista.component */ 70517);












let AhorrosPage = class AhorrosPage {
    constructor(ahorros, modalCtrol, routerOutlet, alert, loading, toast, aRoute) {
        this.ahorros = ahorros;
        this.modalCtrol = modalCtrol;
        this.routerOutlet = routerOutlet;
        this.alert = alert;
        this.loading = loading;
        this.toast = toast;
        this.aRoute = aRoute;
        this.getTipoAhorro = src_app_shared_globals__WEBPACK_IMPORTED_MODULE_5__.Globals.getTipoAhorro;
        this.initHeaderOptions();
        this.aRoute.params.subscribe((params) => {
            if (params.create) {
                this.openModalForm();
            }
        });
    }
    ngOnInit() {
    }
    ngAfterViewInit() {
        this.loading.show('Cargando ahorros');
        this.getAhorros();
    }
    getAhorros() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            (yield this.ahorros.getAll(1)).subscribe((list) => {
                this.fullList = list;
                this.loading.hide();
                this.filtrar();
            });
        });
    }
    initHeaderOptions() {
        this.headerOptions = {
            endIcon: 'add',
            endFunction: () => this.openModalForm()
        };
    }
    openModalForm(ahorroEdit) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrol.create({
                animated: true,
                mode: 'md',
                component: _form_form_component__WEBPACK_IMPORTED_MODULE_6__.FormComponent,
                swipeToClose: false,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: ahorroEdit ? { ahorroEdit } : null
            });
            yield modal.present();
            const { update } = (yield modal.onDidDismiss()).data || {};
            if (update) {
                yield this.loading.show('Cargando ahorros');
                this.getAhorros();
            }
        });
    }
    openModalView(ahorro) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const modal = yield this.modalCtrol.create({
                animated: true,
                mode: 'md',
                component: _vista_vista_component__WEBPACK_IMPORTED_MODULE_7__.VistaComponent,
                swipeToClose: false,
                presentingElement: this.routerOutlet.nativeEl,
                componentProps: { ahorro }
            });
            yield modal.present();
            const { data } = (yield modal.onDidDismiss());
            if (data === null || data === void 0 ? void 0 : data.update) {
                this.loading.show('Cargando ahorros');
                this.getAhorros();
            }
        });
    }
    openModalEdit(ahorro) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            this.openModalForm(ahorro);
        });
    }
    alertDelete(ahorro) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                header: 'Eliminar',
                message: 'Está seguro de eliminar el ahorro?',
                buttons: [{
                        text: 'Si',
                        handler: (__) => {
                            this.delete(ahorro);
                        }
                    },
                    {
                        role: 'cancel', text: 'No'
                    }]
            });
            return yield alert.present();
        });
    }
    delete(ahorro) {
        this.loading.show('Eliminando Ahorro');
        this.ahorros.delete(ahorro.id, ahorro.tipo).subscribe(({ success }) => {
            if (success) {
                this.getAhorros();
            }
            this.loading.hide();
        }, (except) => {
            const { error } = except;
            if (error.message.includes('Integrity constraint')) {
                this.toast.show({
                    message: 'No se puede eliminar ahorro ya que está compartido',
                    icon: 'close',
                    duration: 1500
                });
                this.loading.hide();
            }
        });
    }
    filtrar() {
        const options = {
            0: () => this.list = this.fullList,
            1: () => this.list = this.fullList.filter(i => !i.compartido),
            2: () => this.list = this.fullList.filter(i => i.compartido)
        };
        options[this.segment.value || 0]();
    }
};
AhorrosPage.ctorParameters = () => [
    { type: src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__.AhorrosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.IonRouterOutlet },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.AlertController },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__.LoadingService },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__.ToastService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__.ActivatedRoute }
];
AhorrosPage.propDecorators = {
    segment: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.ViewChild, args: ['IonSegment',] }]
};
AhorrosPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-ahorros',
        template: _ahorros_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_ahorros_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AhorrosPage);



/***/ }),

/***/ 91421:
/*!******************************************************!*\
  !*** ./src/app/pages/ahorros/form/form.component.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FormComponent": () => (/* binding */ FormComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _form_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./form.component.html?ngResource */ 18853);
/* harmony import */ var _form_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./form.component.scss?ngResource */ 33554);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_components_calendar_calendar_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/calendar/calendar.component */ 33373);
/* harmony import */ var src_app_components_contacts_chooser_contacts_chooser_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/components/contacts-chooser/contacts-chooser.component */ 12202);
/* harmony import */ var src_app_models_ahorro_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/models/ahorro.model */ 20034);
/* harmony import */ var src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/ahorros.service */ 58680);
/* harmony import */ var src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/forms.service */ 76311);
/* harmony import */ var src_app_shared_globals__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/globals */ 19432);












let FormComponent = class FormComponent {
    constructor(modalCtrl, popoverCtrl, formService, ahorrosService, popoverController) {
        this.modalCtrl = modalCtrl;
        this.popoverCtrl = popoverCtrl;
        this.formService = formService;
        this.ahorrosService = ahorrosService;
        this.popoverController = popoverController;
        this.tiposAhorro = src_app_shared_globals__WEBPACK_IMPORTED_MODULE_7__.Globals.tiposAhorro;
        this.form = this.formService.initForm(new src_app_models_ahorro_model__WEBPACK_IMPORTED_MODULE_4__.AhorroModel());
        this.form.get('requiereFecha').valueChanges.subscribe((value) => {
            if (value) {
                this.form.get('fechaMeta').clearValidators();
            }
            else {
                this.form.get('fechaMeta').setValidators(_angular_forms__WEBPACK_IMPORTED_MODULE_8__.Validators.required);
            }
            this.form.get('fechaMeta').updateValueAndValidity();
        });
        this.initHeaderOptions();
    }
    ngOnInit() {
        if (this.ahorroEdit) {
            this.form.patchValue(this.ahorroEdit);
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            !this.ahorroEdit.fechaMeta && this.form.get('requiereFecha').setValue(true);
        }
    }
    initHeaderOptions() {
        this.headerOptions = {
            startIcon: '-',
            startFunction: () => { },
            endIcon: 'close',
            endFunction: () => this.modalCtrl.dismiss()
        };
    }
    openDatePicker() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverCtrl.create({
                component: src_app_components_calendar_calendar_component__WEBPACK_IMPORTED_MODULE_2__.CalendarComponent,
                mode: 'ios',
                backdropDismiss: true,
                showBackdrop: true,
                size: 'auto',
                cssClass: 'pop-date',
            });
            yield popover.present();
            const { date } = (yield popover.onDidDismiss()).data || { date: '' };
            this.form.get('fechaMeta').setValue(date);
        });
    }
    save() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            if (this.form.value.requiereFecha) {
                delete this.form.value.fechaMeta;
            }
            (yield this.ahorrosService.save(this.form.value, this.ahorroEdit ? true : false)).subscribe(({ success }) => {
                if (success) {
                    this.modalCtrl.dismiss({ update: true });
                }
            });
        });
    }
    showContacts(ev) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__awaiter)(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: src_app_components_contacts_chooser_contacts_chooser_component__WEBPACK_IMPORTED_MODULE_3__.ContactsChooserComponent,
                cssClass: 'my-custom-class',
                event: ev,
                translucent: true,
                alignment: 'center',
                componentProps: {
                    idAhorro: this.ahorroEdit.id
                }
            });
            yield popover.present();
            const { role, data } = yield popover.onDidDismiss();
        });
    }
};
FormComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.PopoverController },
    { type: src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_6__.FormsService },
    { type: src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_5__.AhorrosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_10__.PopoverController }
];
FormComponent.propDecorators = {
    ahorroEdit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_11__.Input }]
};
FormComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_9__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_11__.Component)({
        selector: 'app-form',
        template: _form_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_form_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FormComponent);



/***/ }),

/***/ 70517:
/*!********************************************************!*\
  !*** ./src/app/pages/ahorros/vista/vista.component.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VistaComponent": () => (/* binding */ VistaComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _vista_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vista.component.html?ngResource */ 5193);
/* harmony import */ var _vista_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vista.component.scss?ngResource */ 7258);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/ahorros.service */ 58680);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/toast.service */ 84465);








let VistaComponent = class VistaComponent {
    constructor(modalCtrl, ahorroService, alertController, loading, toast) {
        this.modalCtrl = modalCtrl;
        this.ahorroService = ahorroService;
        this.alertController = alertController;
        this.loading = loading;
        this.toast = toast;
        this.update = false;
        this.initHeaderOptions();
    }
    ngOnInit() {
        this.loading.show('Cargando ahorro');
        this.getAhorro(this.ahorro.id);
    }
    initHeaderOptions() {
        this.headerOptions = {
            startIcon: '-',
            startFunction: () => { },
            endIcon: 'close',
            endFunction: () => this.modalCtrl.dismiss({ update: this.update })
        };
    }
    getAhorro(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const ahorro = yield this.ahorroService.getOne(id);
            ahorro.subscribe((result) => {
                this.datosAhorro = result;
                this.loading.hide();
            });
        });
    }
    selectIntervalo(monto) {
        const data = {
            id: monto.id,
            chec: !monto.chec,
            idAhorro: this.datosAhorro.id,
            ahorrado: !monto.chec ? (this.datosAhorro.ahorrado + monto.valor) : (this.datosAhorro.ahorrado - monto.valor)
        };
        this.loading.show(`${monto.chec ? 'Quitando' : 'Agregando'} Intervalo`);
        this.ahorroService.selectIntervalo(data).subscribe(({ success }) => {
            if (success) {
                this.getAhorro(this.datosAhorro.id);
                this.update = true;
            }
        });
    }
    montoTrackBy(_, monto) {
        return monto.id;
    }
    showAddMonto() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Cuanto vas a ahorrar?',
                inputs: [
                    {
                        name: 'valor',
                        type: 'number',
                        placeholder: '$'
                    }
                ],
                buttons: [{
                        text: 'Aceptar',
                        handler: ({ valor }) => {
                            if (valor) {
                                const { objetivo, ahorrado } = this.datosAhorro;
                                if (valor <= (objetivo - ahorrado)) {
                                    this.addMonto(valor);
                                }
                                else {
                                    this.toast.show({
                                        message: 'El monto ingresado sobrepasa el total del ahorro',
                                        icon: 'close',
                                        duration: 1500,
                                        position: 'bottom'
                                    });
                                }
                            }
                        }
                    },
                    {
                        role: 'cancel', text: 'Cancelar'
                    }]
            });
            yield alert.present();
        });
    }
    addMonto(valor) {
        const data = {
            monto: +valor,
            idAhorro: this.datosAhorro.id
        };
        this.loading.show(`Agregando monto`);
        this.ahorroService.addMonto(data).subscribe(({ success }) => {
            if (success) {
                this.update = true;
                this.getAhorro(this.datosAhorro.id);
            }
        });
    }
};
VistaComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ModalController },
    { type: src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__.AhorrosService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__.LoadingService },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_4__.ToastService }
];
VistaComponent.propDecorators = {
    ahorro: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.Input }]
};
VistaComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-vista',
        template: _vista_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_vista_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], VistaComponent);



/***/ }),

/***/ 59822:
/*!************************************************************!*\
  !*** ./src/app/pages/ahorros/ahorros.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"Ahorros\" [datos]=\"headerOptions\"></app-header>\r\n<ion-segment #IonSegment mode=\"ios\" id=\"segment\" (ionChange)=\"filtrar()\" value=\"0\"  color=\"primary\">\r\n  <ion-segment-button value=\"0\">\r\n    <ion-label>Todos</ion-label>\r\n  </ion-segment-button>\r\n  <ion-segment-button value=\"1\">\r\n    <ion-label>Propios</ion-label>\r\n  </ion-segment-button>\r\n  <ion-segment-button value=\"2\">\r\n    <ion-label>Compartidos</ion-label>\r\n  </ion-segment-button>\r\n</ion-segment>\r\n<ion-content>\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col size=\"12\" size-md=\"4\" *ngFor=\"let ahorro of list\" >\r\n        <ion-card class=\"pointer item\">\r\n          <ion-grid fixed>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-card-header class=\"ion-no-padding\">\r\n                  <ion-text>\r\n                    <h5>\r\n                      {{ ahorro.nombre | titlecase }}\r\n                    </h5>\r\n                  </ion-text>\r\n                  <ion-card-subtitle>{{ahorro.percent}}%</ion-card-subtitle>\r\n                  <ion-progress-bar value=\"{{ahorro.percent/100}}\" ></ion-progress-bar>\r\n                  <ion-card-subtitle class=\"meta-tipo\">                     \r\n                    <span>\r\n                      Meta: {{ ahorro.objetivo | currency:\"$\":\"symbol\"  }}\r\n                    </span>                    \r\n                    <small>\r\n                      Tipo: {{ getTipoAhorro(ahorro.tipo_ahorro) }}\r\n                    </small>\r\n                  </ion-card-subtitle>\r\n                  <ion-card-subtitle class=\"meta-tipo\">\r\n                    <span>\r\n                      Falta: {{ (ahorro.objetivo - ahorro.ahorrado) | currency:\"$\":\"symbol\"  }}\r\n                    </span>\r\n                    <span *ngIf=\"ahorro?.fechaMeta\">\r\n                      <small>\r\n                        Fecha Meta: {{ ahorro.fechaMeta | date}}\r\n                      </small> \r\n                    </span>\r\n                  </ion-card-subtitle>\r\n                  \r\n                </ion-card-header>\r\n                <ion-card-content class=\"ion-text-end\">\r\n                  <ion-button shape=\"round\" color=\"primary\" (click)=\"openModalView(ahorro)\">\r\n                    <ion-icon name=\"eye\"></ion-icon>\r\n                  </ion-button>\r\n                  <ion-button shape=\"round\" color=\"secondary\" (click)=\"openModalEdit(ahorro)\" *ngIf=\"!ahorro.compartido\">\r\n                    <ion-icon name=\"create\"></ion-icon>\r\n                  </ion-button>\r\n                  <ion-button shape=\"round\" color=\"danger\" (click)=\"alertDelete(ahorro)\" *ngIf=\"!ahorro.compartido\">\r\n                    <ion-icon name=\"trash\" ></ion-icon>\r\n                  </ion-button>                \r\n                </ion-card-content>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>          \r\n        </ion-card>\r\n      </ion-col>\r\n      <ion-col size=\"12\" *ngIf=\"!list?.length\">\r\n        <ion-card class=\"ion-padding\">\r\n          <ion-card-title class=\"ion-text-center\">\r\n            No tienes ahorros\r\n          </ion-card-title>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n";

/***/ }),

/***/ 18853:
/*!*******************************************************************!*\
  !*** ./src/app/pages/ahorros/form/form.component.html?ngResource ***!
  \*******************************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"{{ ahorroEdit ? 'Actualizar' : 'Crear' }} Ahorro\" [datos]=\"headerOptions\"></app-header>\r\n<ion-content>\r\n  <ion-list lines=\"none\" class=\"ion-no-margin\" [formGroup]=\"form\">\r\n    <ion-item>\r\n      <ion-label position=\"floating\">Nombre</ion-label>\r\n      <ion-input formControlName=\"nombre\"></ion-input>\r\n    </ion-item>\r\n    <ion-item *ngIf=\"!ahorroEdit\">\r\n      <ion-label position=\"floating\">Objetivo ahorro</ion-label>\r\n      <ion-input placeholder=\"¿Cuanto quieres ahorrar?\" formControlName=\"objetivo\" type=\"number\"></ion-input>\r\n    </ion-item>\r\n    <ion-item *ngIf=\"!ahorroEdit\">\r\n      <ion-label position=\"floating\">Tipo de ahorro</ion-label>\r\n      <ion-select interface=\"action-sheet\" mode=\"ios\" formControlName=\"tipo_ahorro\">\r\n        <ion-select-option *ngFor=\"let tipo of tiposAhorro\"  [value]=\"tipo.id\">{{ tipo.nombre }}</ion-select-option>\r\n      </ion-select>\r\n    </ion-item>\r\n    <ion-item *ngIf=\"form.get('tipo_ahorro').value === 2 && !ahorroEdit\" >\r\n      <ion-label position=\"floating\">Intervalo</ion-label>\r\n      <ion-input formControlName=\"intervalo\" placeholder=\"Intervalo de lo que vas a ahorrar\"  type=\"number\"></ion-input>\r\n    </ion-item>\r\n    <ion-item >\r\n      <ion-label>Sin fecha meta</ion-label>\r\n      <ion-toggle formControlName=\"requiereFecha\"></ion-toggle>\r\n    </ion-item>\r\n    <ion-item *ngIf=\"!form.get('requiereFecha').value\">\r\n      <ion-label position=\"floating\">Fecha Meta</ion-label>\r\n      <ion-input formControlName=\"fechaMeta\" (click)=\"openDatePicker()\" readonly></ion-input>\r\n    </ion-item>\r\n\r\n    <ion-item *ngIf=\"ahorroEdit\">\r\n      <ion-label>Compartir Ahorro</ion-label>\r\n      <ion-button id=\"share-button\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"showContacts($event)\">\r\n        <ion-icon  name=\"people\" ></ion-icon>\r\n      </ion-button>\r\n    </ion-item>\r\n  </ion-list>\r\n</ion-content>\r\n\r\n<ion-footer class=\"ion-text-center ion-no-border\" collapse=\"fade\">\r\n  <ion-button color=\"primary\" [disabled]=\"form.invalid\"  (click)=\"save()\" > {{ ahorroEdit ? 'Actualizar' : 'Guardar' }} </ion-button>\r\n  <ion-button color=\"danger\" (click)=\"modalCtrl.dismiss()\"> Cancelar </ion-button>\r\n</ion-footer>";

/***/ }),

/***/ 5193:
/*!*********************************************************************!*\
  !*** ./src/app/pages/ahorros/vista/vista.component.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<app-header [title]=\"datosAhorro?.nombre || ''\" [datos]=\"headerOptions\"></app-header>\r\n<ion-content class=\"content\">\r\n  <ion-card>\r\n    <ion-card-content>\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col [size]=\"datosAhorro?.tipo_ahorro === 1 ? 9 : 12\">\r\n            <ion-row>\r\n              <ion-col size=\"12\" class=\"objetivo\">\r\n                <ion-text >\r\n                  <h4>\r\n                    Objetivo: {{ datosAhorro?.objetivo | currency:\"$\":\"symbol\"}}\r\n                  </h4>\r\n                </ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n            <ion-row>\r\n              <ion-col size=\"12\">\r\n                <ion-text >\r\n                  <h4>Ahorrado: {{ (datosAhorro?.ahorrado) | currency:\"$\":\"symbol\" }}</h4>\r\n                </ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-col>\r\n          <ion-col  *ngIf=\"datosAhorro?.tipo_ahorro === 1\" size=\"3\" class=\"ion-text-end btn-add-container \" >\r\n            <ion-button fill=\"solid\" color=\"primary\" size=\"small\" (click)=\"showAddMonto()\">\r\n              <ion-icon name=\"add\"></ion-icon>\r\n            </ion-button>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-card-content>\r\n  </ion-card>\r\n\r\n  <ion-card>\r\n    <ion-list lines=\"full\" *ngIf=\"datosAhorro?.tipo_ahorro === 1\" >\r\n      <ion-item-sliding *ngFor=\"let monto of datosAhorro?.montos || []\">\r\n        <ion-item>\r\n          <ion-label slot=\"start\">{{ monto.valor | currency:\"$\":\"symbol\" }}</ion-label>     \r\n          <ion-label slot=\"end\">{{ monto.created_at | date}}</ion-label>        \r\n        </ion-item>\r\n        <ion-item-options side=\"end\">\r\n          <ion-item-option>\r\n            <ion-icon name=\"help-circle-outline\"></ion-icon>\r\n          </ion-item-option>\r\n        </ion-item-options>\r\n      </ion-item-sliding>\r\n      <ion-item *ngIf=\"!datosAhorro?.montos?.length\" class=\"ion-text-center\">\r\n        <ion-label> No hay montos </ion-label>\r\n      </ion-item>\r\n    </ion-list>\r\n\r\n    <ion-list lines=\"full\" *ngIf=\"datosAhorro?.tipo_ahorro === 2\" >\r\n      <ion-grid fixed>\r\n        <ion-row>\r\n          <ion-col size=\"4\" size-md=\"3\" class=\"cell\" *ngFor=\"let monto of (datosAhorro?.montos || []); trackBy: montoTrackBy\" [ngClass]=\"{'checked': monto.chec}\"  (click)=\"selectIntervalo(monto)\">\r\n            {{ monto.valor | currency:\"$\":\"symbol\" }}\r\n            <ion-icon name=\"checkmark-outline\" color=\"primary\" *ngIf=\"monto.chec\"></ion-icon>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </ion-list>\r\n  </ion-card>\r\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_ahorros_ahorros_module_ts.js.map