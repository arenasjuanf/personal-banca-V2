"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_register_register_module_ts"],{

/***/ 82638:
/*!**********************************************************!*\
  !*** ./src/app/auth/register/register-routing.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageRoutingModule": () => (/* binding */ RegisterPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page */ 41351);




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_0__.RegisterPage
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ 38270:
/*!**************************************************!*\
  !*** ./src/app/auth/register/register.module.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPageModule": () => (/* binding */ RegisterPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register-routing.module */ 82638);
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page */ 41351);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);








let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _register_routing_module__WEBPACK_IMPORTED_MODULE_0__.RegisterPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_7__.RxReactiveFormsModule
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_1__.RegisterPage]
    })
], RegisterPageModule);



/***/ }),

/***/ 41351:
/*!************************************************!*\
  !*** ./src/app/auth/register/register.page.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterPage": () => (/* binding */ RegisterPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./register.page.html?ngResource */ 34089);
/* harmony import */ var _register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./register.page.scss?ngResource */ 39105);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var src_app_models_register_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/models/register.model */ 78394);
/* harmony import */ var src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/auth.service */ 37556);
/* harmony import */ var src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/forms.service */ 76311);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/toast.service */ 84465);










let RegisterPage = class RegisterPage {
    constructor(authService, forms, toast, router, loading) {
        this.authService = authService;
        this.forms = forms;
        this.toast = toast;
        this.router = router;
        this.loading = loading;
        this.form = this.forms.initForm(new src_app_models_register_model__WEBPACK_IMPORTED_MODULE_2__.RegisterModel());
    }
    ngOnInit() {
    }
    register() {
        if (this.form.invalid) {
            this.form.markAllAsTouched();
            return;
        }
        this.loading.show('Registrando usuario');
        this.authService.register(this.form.value).subscribe(({ success, msj }) => {
            this.toast.show({
                message: success ? 'Registro Exitoso' : msj,
                icon: success ? 'checkmark' : 'close',
                position: 'bottom',
                duration: 1500
            });
            this.loading.hide();
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            success && this.router.navigateByUrl('pages/auth');
        });
    }
};
RegisterPage.ctorParameters = () => [
    { type: src_app_services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: src_app_services_forms_service__WEBPACK_IMPORTED_MODULE_4__.FormsService },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_5__.LoadingService }
];
RegisterPage = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-register',
        template: _register_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_register_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], RegisterPage);



/***/ }),

/***/ 78394:
/*!******************************************!*\
  !*** ./src/app/models/register.model.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RegisterModel": () => (/* binding */ RegisterModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);


class RegisterModel {
    constructor() {
        this.aceptarTerminos = 0;
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], RegisterModel.prototype, "nombres", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], RegisterModel.prototype, "apellidos", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.email)({ message: 'el campo debe ser un email' }),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], RegisterModel.prototype, "email", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], RegisterModel.prototype, "password", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' }),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.compare)({ fieldName: 'password', message: 'contraseñas no coinciden' })
], RegisterModel.prototype, "repassword", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.noneOf)({ message: 'debe aceptar los términos y condiciones para continuar', matchValues: [0, false] })
], RegisterModel.prototype, "aceptarTerminos", void 0);


/***/ }),

/***/ 39105:
/*!*************************************************************!*\
  !*** ./src/app/auth/register/register.page.scss?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "ion-grid {\n  font-family: \"Poppins\", sans-serif;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-grid ion-row {\n  height: auto;\n}\nion-grid ion-row ion-img {\n  width: 75%;\n  margin: auto;\n}\nion-grid ion-row h1 {\n  font-weight: 700;\n  margin: 0 0 0 0;\n}\nion-grid ion-row .form-cont {\n  background-color: #ffffff8a;\n  border-radius: 25px;\n  border: 3px solid #b5abab40;\n}\nion-grid ion-row ion-col {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-grid ion-row ion-col .input {\n  border-radius: 20px;\n  border: 1px solid #3780ff9e;\n  margin: 10px 0 0px 0;\n}\nion-grid ion-row ion-col .mantener-sesion {\n  margin-bottom: 10px;\n}\nion-grid ion-row ion-col .mantener-sesion ion-label {\n  margin-left: 10px;\n}\nion-grid ion-row ion-col .mantener-sesion::part(native) {\n  background-color: transparent;\n}\nion-grid ion-row ion-col .recuperar-clave {\n  margin-top: 10px;\n}\nion-grid ion-row ion-col ion-button {\n  border: 3px solid #b5abab12;\n  width: 60%;\n  margin: auto;\n}\nion-content::part(scroll) {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-content::part(background) {\n  background: url('figures2.svg');\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.text-terminos {\n  color: var(--ion-color-primary);\n}\nion-text {\n  display: flex;\n  margin-bottom: 10px;\n  justify-content: space-between;\n}\nion-text h1 {\n  margin-bottom: 0;\n}\nion-text ion-icon {\n  margin: auto 0 auto 0;\n}\n.terms {\n  margin: 10px 5px 5px 5px;\n  display: flex;\n  justify-content: space-around;\n}\n.terms ion-checkbox {\n  margin-top: auto;\n  margin-bottom: auto;\n}\n.terms b {\n  color: var(--ion-color-primary);\n}\n.terms-content {\n  margin: 20px;\n  height: 100%;\n  overflow-y: auto;\n  border: 2px solid #4854e038;\n  border-radius: 5px;\n  padding: 5px;\n  text-align: justify;\n}\n.terms-content h5 {\n  text-align: center;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJlZ2lzdGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQTtFQUVJLGtDQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7QUFGSjtBQUtJO0VBQ0ksWUFBQTtBQUhSO0FBS1E7RUFDSSxVQUFBO0VBQ0EsWUFBQTtBQUhaO0FBTVE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7QUFKWjtBQU9RO0VBQ0ksMkJBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0FBTFo7QUFRUTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0FBTlo7QUFRWTtFQUNJLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSxvQkFBQTtBQU5oQjtBQVNZO0VBSUksbUJBQUE7QUFWaEI7QUFPZ0I7RUFDSSxpQkFBQTtBQUxwQjtBQVNnQjtFQUNJLDZCQUFBO0FBUHBCO0FBV1k7RUFDSSxnQkFBQTtBQVRoQjtBQVlZO0VBQ0ksMkJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQVZoQjtBQWlCQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0FBZEo7QUFpQkE7RUFDRywrQkFBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QUFkSDtBQWlCQTtFQUNJLCtCQUFBO0FBZEo7QUFrQkE7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtBQWZKO0FBZ0JJO0VBQ0ksZ0JBQUE7QUFkUjtBQWdCSTtFQUNJLHFCQUFBO0FBZFI7QUFpQkE7RUFDSSx3QkFBQTtFQUNBLGFBQUE7RUFDQSw2QkFBQTtBQWRKO0FBZUk7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0FBYlI7QUFlSTtFQUNJLCtCQUFBO0FBYlI7QUFpQkE7RUFDSSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQWRKO0FBZ0JJO0VBQ0ksa0JBQUE7RUFDQSxpQkFBQTtBQWRSIiwiZmlsZSI6InJlZ2lzdGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuaW9uLWdyaWR7XHJcblxyXG4gICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZjtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblxyXG5cclxuICAgIGlvbi1yb3d7XHJcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG5cclxuICAgICAgICBpb24taW1ne1xyXG4gICAgICAgICAgICB3aWR0aDogNzUlO1xyXG4gICAgICAgICAgICBtYXJnaW46IGF1dG87XHJcbiAgICAgICAgfVxyXG4gICAgXHJcbiAgICAgICAgaDF7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMCAwIDAgMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC5mb3JtLWNvbnR7ICAgICAgIFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmOGE7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDI1cHg7XHJcbiAgICAgICAgICAgIGJvcmRlcjogM3B4IHNvbGlkICNiNWFiYWI0MDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlvbi1jb2x7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5cclxuICAgICAgICAgICAgLmlucHV0e1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMzNzgwZmY5ZTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMTBweCAwIDBweCAwO1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAubWFudGVuZXItc2VzaW9ue1xyXG4gICAgICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuXHJcbiAgICAgICAgICAgICAgICAmOjpwYXJ0KG5hdGl2ZSl7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5yZWN1cGVyYXItY2xhdmV7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAzcHggc29saWQgI2I1YWJhYjEyO1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDYwJTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogYXV0bztcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcbmlvbi1jb250ZW50OjpwYXJ0KHNjcm9sbCl7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG5pb24tY29udGVudDo6cGFydChiYWNrZ3JvdW5kKXtcclxuICAgYmFja2dyb3VuZDogdXJsKC4uLy4uLy4uL2Fzc2V0cy9maWd1cmVzMi5zdmcpO1xyXG4gICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG59XHJcblxyXG4udGV4dC10ZXJtaW5vc3tcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSlcclxufVxyXG5cclxuXHJcbmlvbi10ZXh0e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBoMXtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgfVxyXG4gICAgaW9uLWljb257XHJcbiAgICAgICAgbWFyZ2luOiBhdXRvIDAgYXV0byAwO1xyXG4gICAgfVxyXG59XHJcbi50ZXJtc3tcclxuICAgIG1hcmdpbjogMTBweCA1cHggNXB4IDVweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcclxuICAgIGlvbi1jaGVja2JveHtcclxuICAgICAgICBtYXJnaW4tdG9wOiBhdXRvO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IGF1dG87XHJcbiAgICB9XHJcbiAgICBie1xyXG4gICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSlcclxuICAgIH1cclxufVxyXG5cclxuLnRlcm1zLWNvbnRlbnR7XHJcbiAgICBtYXJnaW46IDIwcHg7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICBvdmVyZmxvdy15OiBhdXRvO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgIzQ4NTRlMDM4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgcGFkZGluZzogNXB4O1xyXG4gICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxuXHJcbiAgICBoNXtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICB9XHJcbn0iXX0= */";

/***/ }),

/***/ 34089:
/*!*************************************************************!*\
  !*** ./src/app/auth/register/register.page.html?ngResource ***!
  \*************************************************************/
/***/ ((module) => {

module.exports = "<!-- eslint-disable max-len-->\r\n\r\n\r\n\r\n<ion-content>\r\n  <ion-grid class=\"ion-padding\">\r\n    <ion-row>\r\n      \r\n      <ion-col  size-md=\"6\" size-xs=\"12\">\r\n        <ion-img src=\"./assets/icon/logo.svg\" class=\"ion-padding\"></ion-img>\r\n      </ion-col>\r\n\r\n\r\n      <ion-col size-md=\"6\" size-xs=\"12\" class=\"ion-padding form-cont\" [formGroup]=\"form\">\r\n\r\n        <ion-text class=\"ion-text-center\">\r\n          <ion-icon size=\"large\" name=\"chevron-back-outline\" class=\"pointer\" routerLink=\"auth\"></ion-icon>\r\n          <h1>Regístrate</h1>\r\n          <ion-icon name=\"\" ></ion-icon>\r\n        </ion-text>\r\n\r\n        <ion-item  class=\"input\">\r\n          <ion-input placeholder=\"Nombres\" formControlName=\"nombres\"></ion-input>\r\n        </ion-item>\r\n        <ion-item  class=\"input\">\r\n          <ion-input placeholder=\"Apellidos\" formControlName=\"apellidos\"></ion-input>\r\n        </ion-item>\r\n        <ion-item  class=\"input\">\r\n          <ion-input placeholder=\"Correo Electrónico\" formControlName=\"email\"></ion-input>\r\n        </ion-item>\r\n        <ion-item  class=\"input\">\r\n          <ion-input type=\"password\" placeholder=\"Contraseña\" formControlName=\"password\"></ion-input>\r\n        </ion-item>\r\n        <ion-item  class=\"input\">\r\n          <ion-input type=\"password\" placeholder=\"Confirmar Contraseña\" formControlName=\"repassword\"></ion-input>\r\n        </ion-item>\r\n\r\n        <span class=\"terms\">\r\n          <ion-checkbox formControlName=\"aceptarTerminos\"></ion-checkbox>\r\n          <ion-label> <small>Acepto <b id=\"terms-button\">términos y condiciones</b></small> </ion-label>\r\n        </span>\r\n      \r\n        <!-- eslint-disable-next-line max-len -->\r\n        <ion-button color=\"primary\" class=\"login-button ion-activatable ripple-parent\" shape=\"round\" [disabled]=\"form.invalid\" (click)=\"register()\">\r\n          <ion-icon name=\"enter-outline\" slot=\"start\"></ion-icon>\r\n          Registrarse\r\n          <ion-ripple-effect></ion-ripple-effect>\r\n        </ion-button>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n\r\n<ion-modal trigger=\"terms-button\" [swipeToClose]=\"true\" #modalTerms>\r\n  <ng-template>\r\n    <div class=\"terms-content\">\r\n      <h5>Propiedad del contenido del Portal web -Copyright-</h5>\r\n      <p>Está prohibida la reproducción total o parcial, traducción, inclusión, transmisión, almacenamiento o acceso a través de medios analógicos, digitales o de cualquier otro sistema o tecnología creada o por crearse, sin autorización previa y escrita de Personal Banca.</p>\r\n      <h5>Declaración de Privacidad</h5>\r\n      <p>La App Personal Banca es una instancia comprometida con los usuarios que además de proveer información, vela por su calidad y fidelidad. Para ello institucionalizó la Declaración de Privacidad, la cual determina y garantiza el debido proceso para utilizar información personal y privada de personas inscritas en el portal para no infligir de ninguna manera las disposiciones contenidas en la Ley Estatutaria del Habeas Data (Ley 1581 del 2012), reglamentada mediante el decreto 1377 del 2013 y en la Ley de Privacidad o Habeas Data Colombiana (Ley 1266 de 2008).</p>\r\n      <h5>Recolección de información personal</h5>\r\n      <p>La App Personal Banca recolecta información personal de sus usuarios para garantizar algunas de sus actividades. Los datos que con mayor frecuencia se solicitan son: nombre, identificación, dirección de correo electrónico, dirección de residencia, número telefónico.</p>\r\n      <p>También cuenta con información que se captura automáticamente relacionada con el hardware y software de los usuarios o clientes de Personal Banca, como dirección IP, tipo de explorador de Internet utilizado, nombre de dominio, tiempos de acceso y direcciones de sitios Web. Esta información es utilizada por el portal para garantizar la operación del servicio, asegurar su calidad y brindar estadísticas generales sobre el uso de la app.</p>\r\n      <h5>Habeas DATA</h5>\r\n      <p>Lo anterior es en base a la Ley 1266 de 2008 se encarga de regular el manejo de la información contenida en bases de datos personales, en especial la financiera, crediticia, comercial, casi inmediatamente es promulgada Ley 1273 de 2009 que por decirlo de una manera son los dientes que utiliza el estado para hacer cumplir dicho principio consagrando los  delitos de informáticos, ya por ultimo  Ley 1581 de 2012 y finalmente, la fase que podría denominarse de reglamentación administrativa, que ha implicado la puesta en funcionamiento del sistema de registro de bases de datos personales o registro de ficheros – RNBD ante la Superintendencia de Industria y Comercio.</p>\r\n      <p>La ley 1581 de 2012 dicta las disposiciones generales para la protección de datos personales, desarrolla el derecho constitucional de todos los titulares de la información puedan conocer, actualizar y rectificar su información personal que haya sido recogida en bases de datos o archivos.</p>\r\n    </div>\r\n    <ion-button expand=\"block\" fill=\"solid\" shape=\"round\" class=\"ion-margin\" (click)=\"modalTerms.dismiss()\">\r\n      Cerrar <ion-icon slot=\"start\" name=\"close\"></ion-icon>\r\n    </ion-button>\r\n  </ng-template>\r\n</ion-modal>";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_register_register_module_ts.js.map