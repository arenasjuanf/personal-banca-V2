"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_agregar_agregar_module_ts"],{

/***/ 8421:
/*!*********************************************************!*\
  !*** ./src/app/pages/agregar/agregar-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgregarPageRoutingModule": () => (/* binding */ AgregarPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _agregar_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agregar.page */ 52144);




const routes = [
    {
        path: '',
        component: _agregar_page__WEBPACK_IMPORTED_MODULE_0__.AgregarPage
    }
];
let AgregarPageRoutingModule = class AgregarPageRoutingModule {
};
AgregarPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AgregarPageRoutingModule);



/***/ }),

/***/ 55994:
/*!*************************************************!*\
  !*** ./src/app/pages/agregar/agregar.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgregarPageModule": () => (/* binding */ AgregarPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _agregar_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agregar-routing.module */ 8421);
/* harmony import */ var _agregar_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agregar.page */ 52144);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);








let AgregarPageModule = class AgregarPageModule {
};
AgregarPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _agregar_routing_module__WEBPACK_IMPORTED_MODULE_0__.AgregarPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_agregar_page__WEBPACK_IMPORTED_MODULE_1__.AgregarPage]
    })
], AgregarPageModule);



/***/ }),

/***/ 52144:
/*!***********************************************!*\
  !*** ./src/app/pages/agregar/agregar.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AgregarPage": () => (/* binding */ AgregarPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _agregar_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./agregar.page.html?ngResource */ 13122);
/* harmony import */ var _agregar_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./agregar.page.scss?ngResource */ 12329);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);




let AgregarPage = class AgregarPage {
    constructor() { }
    ngOnInit() {
    }
};
AgregarPage.ctorParameters = () => [];
AgregarPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-agregar',
        template: _agregar_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_agregar_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AgregarPage);



/***/ }),

/***/ 12329:
/*!************************************************************!*\
  !*** ./src/app/pages/agregar/agregar.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "ion-content ion-card {\n  background-color: #e3edff;\n  background-image: url('circles.svg');\n  border-radius: 20px;\n}\nion-content ion-card ion-img {\n  max-height: 200px;\n}\nion-content ion-card ion-img::part(image) {\n  max-height: 200px;\n}\nion-content ion-card h2 {\n  font-weight: 700;\n}\nion-content::part(background) {\n  border: 2px solid #b9cae833;\n  margin: 4px;\n  border-radius: 20px;\n  background-color: #e3edff33;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFncmVnYXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0kseUJBQUE7RUFDQSxvQ0FBQTtFQUNBLG1CQUFBO0FBQVI7QUFDUTtFQUNJLGlCQUFBO0FBQ1o7QUFBWTtFQUNJLGlCQUFBO0FBRWhCO0FBRVE7RUFDSSxnQkFBQTtBQUFaO0FBSUk7RUFDSSwyQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0FBRlIiLCJmaWxlIjoiYWdyZWdhci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgICBpb24tY2FyZHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTNlZGZmO1xyXG4gICAgICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybCguLy4uLy4uLy4uL2Fzc2V0cy9jaXJjbGVzLnN2Zyk7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICBpb24taW1ne1xyXG4gICAgICAgICAgICBtYXgtaGVpZ2h0OiAyMDBweDtcclxuICAgICAgICAgICAgJjo6cGFydChpbWFnZSl7XHJcbiAgICAgICAgICAgICAgICBtYXgtaGVpZ2h0OiAyMDBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgaDJ7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgICY6OnBhcnQoYmFja2dyb3VuZCl7XHJcbiAgICAgICAgYm9yZGVyOiAycHggc29saWQgI2I5Y2FlODMzO1xyXG4gICAgICAgIG1hcmdpbjogNHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2UzZWRmZjMzO1xyXG4gICAgfVxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 13122:
/*!************************************************************!*\
  !*** ./src/app/pages/agregar/agregar.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"Agregar item\"></app-header>\r\n<ion-content>\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col size-md=\"6\" size=\"12\" >\r\n        <ion-card class=\"pointer\" routerDirection=\"root\" routerLink=\"/pages/ahorros/crear\">\r\n          <ion-card-header class=\"ion-text-center\">\r\n            <ion-card-title>\r\n              <ion-text color=\"primary\">\r\n                <h2>Ahorro</h2>\r\n              </ion-text>\r\n            </ion-card-title>\r\n          </ion-card-header>\r\n        \r\n          <ion-card-content>\r\n            <ion-img src=\"../../../assets/icon/pigmoney.svg\"></ion-img>\r\n          </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n      <ion-col size-md=\"6\" size=\"12\">\r\n        <ion-card class=\"pointer\" routerDirection=\"root\" routerLink=\"/pages/deudas/crear\">\r\n          <ion-card-header class=\"ion-text-center\">\r\n            <ion-card-title>\r\n              <ion-text color=\"primary\">\r\n                <h2>Deuda</h2>\r\n              </ion-text>\r\n            </ion-card-title>\r\n          </ion-card-header>\r\n        \r\n          <ion-card-content>\r\n            <ion-img src=\"../../../assets/icon/savemoney.svg\"></ion-img>\r\n          </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_agregar_agregar_module_ts.js.map