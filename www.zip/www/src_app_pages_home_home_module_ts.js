"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_home_home_module_ts"],{

/***/ 96610:
/*!***************************************************!*\
  !*** ./src/app/pages/home/home-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 10678);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], HomePageRoutingModule);



/***/ }),

/***/ 57994:
/*!*******************************************!*\
  !*** ./src/app/pages/home/home.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home-routing.module */ 96610);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page */ 10678);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);








let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_0__.HomePageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_1__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 10678:
/*!*****************************************!*\
  !*** ./src/app/pages/home/home.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 8380);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 12260);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/ahorros.service */ 58680);
/* harmony import */ var src_app_services_contacts_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/contacts.service */ 30407);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/storage.service */ 71188);








let HomePage = class HomePage {
    constructor(contactos, ahorros, storage, loading) {
        this.contactos = contactos;
        this.ahorros = ahorros;
        this.storage = storage;
        this.loading = loading;
        this.contadores = [];
    }
    ngOnInit() {
        this.loading.show('Cargando datos');
        this.getContadores();
    }
    getContadores() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            const [ahorros, deudas, contactos] = yield Promise.all([
                ((yield this.ahorros.getAll(1)).toPromise()),
                ((yield this.ahorros.getAll(2)).toPromise()),
                this.contactos.getContacts(userId).toPromise(),
            ]);
            this.contadores = [
                ahorros.length,
                deudas.length,
                contactos.length
            ];
            this.loading.hide();
        });
    }
};
HomePage.ctorParameters = () => [
    { type: src_app_services_contacts_service__WEBPACK_IMPORTED_MODULE_3__.ContactsService },
    { type: src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__.AhorrosService },
    { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__.StorageService },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__.LoadingService }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-home',
        template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 12260:
/*!******************************************************!*\
  !*** ./src/app/pages/home/home.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "ion-card h1 {\n  font-size: 35px;\n}\nion-card .footer {\n  background-color: transparent;\n}\nion-card .footer ion-text {\n  color: white;\n  width: 100%;\n}\nion-card .footer ion-text p {\n  border-top: 1px solid #ffffffcf;\n  font-weight: bold;\n  margin: 0;\n  padding: 5px;\n  width: 100%;\n  text-align: end;\n}\nion-card .footer ion-text p ion-icon {\n  font-size: 20px;\n}\n.ahorros {\n  background-color: #72b5f287;\n}\n.deudas {\n  background-color: #2dd36f8f;\n}\n.contactos {\n  background-color: #195d9f91;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksZUFBQTtBQUFSO0FBRUk7RUFFSSw2QkFBQTtBQURSO0FBRVE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtBQUFaO0FBQ1k7RUFDSSwrQkFBQTtFQUlBLGlCQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQUZoQjtBQUxnQjtFQUNJLGVBQUE7QUFPcEI7QUFLQTtFQUNJLDJCQUFBO0FBRko7QUFLQTtFQUNJLDJCQUFBO0FBRko7QUFLQTtFQUNJLDJCQUFBO0FBRkoiLCJmaWxlIjoiaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZHtcclxuICAgIGgxe1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMzVweDtcclxuICAgIH1cclxuICAgIC5mb290ZXJ7XHJcblxyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgICAgIGlvbi10ZXh0e1xyXG4gICAgICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICBweyAgXHJcbiAgICAgICAgICAgICAgICBib3JkZXItdG9wOiAxcHggc29saWQgI2ZmZmZmZmNmO1xyXG4gICAgICAgICAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAgICAgICAgIHRleHQtYWxpZ246IGVuZDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmFob3Jyb3N7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzJiNWYyODc7XHJcbn1cclxuXHJcbi5kZXVkYXN7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMmRkMzZmOGY7XHJcbn1cclxuXHJcbi5jb250YWN0b3N7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTk1ZDlmOTE7XHJcbn0iXX0= */";

/***/ }),

/***/ 8380:
/*!******************************************************!*\
  !*** ./src/app/pages/home/home.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"Home\"></app-header>\r\n<ion-content>\r\n    <ion-grid fixed>\r\n      <ion-row>\r\n        <ion-col size-md=\"4\" size=\"6\">\r\n          <ion-card class=\"pointer ahorros\" routerDirection=\"root\" routerLink=\"/pages/ahorros\">\r\n            <ion-card-content>\r\n                <ion-text color=\"light\">\r\n                    <h1>{{ contadores[0] || 0 }}</h1>\r\n                </ion-text>\r\n            </ion-card-content>\r\n            <div class=\"footer\">\r\n                <ion-text >\r\n                    <p>\r\n                        <ion-icon name=\"cash-outline\"></ion-icon>\r\n                        Ahorros\r\n                    </p>\r\n                </ion-text>\r\n            </div>\r\n          </ion-card>\r\n        </ion-col>\r\n\r\n        <ion-col  size-md=\"4\" size=\"6\">    \r\n            <ion-card class=\"pointer deudas\" routerDirection=\"root\" routerLink=\"/pages/deudas\">\r\n                <ion-card-content>\r\n                    <ion-text color=\"light\">\r\n                        <h1>{{ contadores[1] || 0 }}</h1>\r\n                    </ion-text>\r\n                </ion-card-content>\r\n                <div class=\"footer\">\r\n                    <ion-text >\r\n                        <p>\r\n                            <ion-icon name=\"wallet-outline\"></ion-icon>\r\n                            Deudas\r\n                        </p>\r\n                    </ion-text>\r\n                </div>\r\n            </ion-card>\r\n        </ion-col>\r\n\r\n        <ion-col  size-md=\"4\" size=\"6\">\r\n            <ion-card class=\"pointer contactos\" routerDirection=\"root\" routerLink=\"/pages/contactos\">\r\n                <ion-card-content>\r\n                    <ion-text color=\"light\">\r\n                        <h1>{{ contadores[2] || 0 }}</h1>\r\n                    </ion-text>\r\n                </ion-card-content>\r\n                <div class=\"footer\">\r\n                    <ion-text >\r\n                        <p>\r\n                            <ion-icon name=\"people-outline\"></ion-icon>\r\n                            Contactos\r\n                        </p>\r\n                    </ion-text>\r\n                </div>\r\n            </ion-card>\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </ion-content>\r\n  ";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_home_home_module_ts.js.map