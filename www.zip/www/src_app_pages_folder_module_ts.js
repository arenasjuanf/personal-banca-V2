"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_folder_module_ts"],{

/***/ 33373:
/*!***********************************************************!*\
  !*** ./src/app/components/calendar/calendar.component.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CalendarComponent": () => (/* binding */ CalendarComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _calendar_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./calendar.component.html?ngResource */ 69253);
/* harmony import */ var _calendar_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./calendar.component.scss?ngResource */ 55917);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_time_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/time.service */ 49260);






let CalendarComponent = class CalendarComponent {
    constructor(popoverCtrl, time) {
        this.popoverCtrl = popoverCtrl;
        this.time = time;
        this.today = new Date().toISOString();
        this.max = new Date(new Date().setFullYear(new Date().getFullYear() + 100)).toISOString();
    }
    ngOnInit() { }
    selectDate(evento) {
        this.popoverCtrl.dismiss({
            date: this.time.parse(evento.detail.value, 'YYYY-M-D')
        });
    }
};
CalendarComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.PopoverController },
    { type: src_app_services_time_service__WEBPACK_IMPORTED_MODULE_2__.TimeService }
];
CalendarComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-calendar',
        template: _calendar_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_calendar_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CalendarComponent);



/***/ }),

/***/ 45642:
/*!*************************************************!*\
  !*** ./src/app/components/components.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ComponentsModule": () => (/* binding */ ComponentsModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _calendar_calendar_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./calendar/calendar.component */ 33373);
/* harmony import */ var _contacts_chooser_contacts_chooser_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contacts-chooser/contacts-chooser.component */ 12202);
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./header/header.component */ 43646);









const components = [
    _header_header_component__WEBPACK_IMPORTED_MODULE_2__.HeaderComponent,
    _calendar_calendar_component__WEBPACK_IMPORTED_MODULE_0__.CalendarComponent,
    _contacts_chooser_contacts_chooser_component__WEBPACK_IMPORTED_MODULE_1__.ContactsChooserComponent
];
let ComponentsModule = class ComponentsModule {
};
ComponentsModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [_ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule, _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule, _angular_router__WEBPACK_IMPORTED_MODULE_8__.RouterModule],
        declarations: components,
        entryComponents: [],
        exports: components
    })
], ComponentsModule);



/***/ }),

/***/ 12202:
/*!***************************************************************************!*\
  !*** ./src/app/components/contacts-chooser/contacts-chooser.component.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactsChooserComponent": () => (/* binding */ ContactsChooserComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _contacts_chooser_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./contacts-chooser.component.html?ngResource */ 31068);
/* harmony import */ var _contacts_chooser_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./contacts-chooser.component.scss?ngResource */ 62905);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/ahorros.service */ 58680);
/* harmony import */ var src_app_services_contacts_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/contacts.service */ 30407);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/storage.service */ 71188);
/* harmony import */ var src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/toast.service */ 84465);











let ContactsChooserComponent = class ContactsChooserComponent {
    constructor(contactosSVc, storage, router, modal, popOver, ahorrosSvc, toast, loader) {
        this.contactosSVc = contactosSVc;
        this.storage = storage;
        this.router = router;
        this.modal = modal;
        this.popOver = popOver;
        this.ahorrosSvc = ahorrosSvc;
        this.toast = toast;
        this.loader = loader;
        this.users = [];
    }
    ngOnInit() {
        this.traerContactos();
        this.traerUsuariosAhorro();
    }
    traerContactos() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            this.contactosSVc.getContacts(userId).subscribe((contactos) => {
                this.listaContactos = contactos;
            });
        });
    }
    goContacts() {
        this.popOver.dismiss();
        this.modal.dismiss();
        this.router.navigateByUrl('/pages/contactos');
    }
    selectContact(contact) {
        const remove = this.isSelected(contact);
        this.loader.show(`${remove ? 'Removiendo' : 'Agregando'} Contacto`);
        this.ahorrosSvc.shareSaving(contact.idUser, this.idAhorro, remove).subscribe(({ success, msj }) => {
            this.loader.hide();
            if (success) {
                this.traerUsuariosAhorro();
            }
            this.toast.show({
                message: msj,
                icon: success ? 'checkmark' : 'close',
                duration: 1500,
                position: 'bottom'
            });
        });
    }
    traerUsuariosAhorro() {
        this.ahorrosSvc.getSharedSavingsUsers(this.idAhorro).subscribe((users) => this.users = users);
    }
    isSelected(contact) {
        return this.users.filter(user => user.fk_id_usuario === contact.idUser).length ? true : false;
    }
};
ContactsChooserComponent.ctorParameters = () => [
    { type: src_app_services_contacts_service__WEBPACK_IMPORTED_MODULE_3__.ContactsService },
    { type: src_app_services_storage_service__WEBPACK_IMPORTED_MODULE_5__.StorageService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_9__.PopoverController },
    { type: src_app_services_ahorros_service__WEBPACK_IMPORTED_MODULE_2__.AhorrosService },
    { type: src_app_services_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_4__.LoadingService }
];
ContactsChooserComponent.propDecorators = {
    idAhorro: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_10__.Input }]
};
ContactsChooserComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_10__.Component)({
        selector: 'app-contacts-chooser',
        template: _contacts_chooser_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_contacts_chooser_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ContactsChooserComponent);



/***/ }),

/***/ 43646:
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HeaderComponent": () => (/* binding */ HeaderComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header.component.html?ngResource */ 2011);
/* harmony import */ var _header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header.component.scss?ngResource */ 75413);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_app_services_menu_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/menu.service */ 98914);





let HeaderComponent = class HeaderComponent {
    constructor(menu) {
        this.menu = menu;
    }
    ngOnInit() { }
    ngOnChanges(changes) {
    }
};
HeaderComponent.ctorParameters = () => [
    { type: src_app_services_menu_service__WEBPACK_IMPORTED_MODULE_2__.MenuService }
];
HeaderComponent.propDecorators = {
    title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }],
    datos: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__.Input }]
};
HeaderComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-header',
        template: _header_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_header_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HeaderComponent);



/***/ }),

/***/ 2567:
/*!************************************************!*\
  !*** ./src/app/pages/folder-routing.module.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PagesPageRoutingModule": () => (/* binding */ PagesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _folder_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./folder.page */ 38650);




const routes = [
    {
        path: '',
        component: _folder_page__WEBPACK_IMPORTED_MODULE_0__.PagesPage,
    },
    {
        path: 'agregar',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_agregar_agregar_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./agregar/agregar.module */ 55994)).then(m => m.AgregarPageModule)
    },
    {
        path: 'home',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_home_home_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./home/home.module */ 57994)).then(m => m.HomePageModule)
    },
    {
        path: 'ahorros',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_ahorros_ahorros_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./ahorros/ahorros.module */ 17590)).then(m => m.AhorrosPageModule)
    },
    {
        path: 'ahorros/:create',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_ahorros_ahorros_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./ahorros/ahorros.module */ 17590)).then(m => m.AhorrosPageModule)
    },
    {
        path: 'deudas',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_deudas_deudas_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./deudas/deudas.module */ 98325)).then(m => m.DeudasPageModule)
    },
    {
        path: 'deudas/:create',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("common"), __webpack_require__.e("src_app_pages_deudas_deudas_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./deudas/deudas.module */ 98325)).then(m => m.DeudasPageModule)
    },
    {
        path: 'noticias',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_noticias_noticias_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./noticias/noticias.module */ 59623)).then(m => m.NoticiasPageModule)
    },
    {
        path: 'contactos',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_pages_contactos_contactos_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./contactos/contactos.module */ 8579)).then(m => m.ContactosPageModule)
    },
];
let PagesPageRoutingModule = class PagesPageRoutingModule {
};
PagesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PagesPageRoutingModule);



/***/ }),

/***/ 35341:
/*!****************************************!*\
  !*** ./src/app/pages/folder.module.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PagesPageModule": () => (/* binding */ PagesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _folder_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./folder-routing.module */ 2567);
/* harmony import */ var _folder_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./folder.page */ 38650);
/* harmony import */ var _components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/components.module */ 45642);








let PagesPageModule = class PagesPageModule {
};
PagesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _folder_routing_module__WEBPACK_IMPORTED_MODULE_0__.PagesPageRoutingModule,
            _components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule,
        ],
        declarations: [_folder_page__WEBPACK_IMPORTED_MODULE_1__.PagesPage]
    })
], PagesPageModule);



/***/ }),

/***/ 58680:
/*!*********************************************!*\
  !*** ./src/app/services/ahorros.service.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AhorrosService": () => (/* binding */ AhorrosService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 86942);
/* harmony import */ var _shared_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../shared/utils */ 22134);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./storage.service */ 71188);






let AhorrosService = class AhorrosService {
    constructor(http, storage) {
        this.http = http;
        this.storage = storage;
    }
    getAll(type = 1) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            return this.http.get(`traerAhorros/${userId}/${type}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((ahorros) => ahorros.map((ahorro) => {
                const { objetivo, ahorrado } = ahorro;
                return Object.assign(Object.assign({}, ahorro), { percent: _shared_utils__WEBPACK_IMPORTED_MODULE_0__.Utils.getPercentage(ahorrado, objetivo) });
            })));
        });
    }
    save(data, update) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            return this.http.post(!update ? 'agregarAhorro' : 'actualizarAhorro', Object.assign(Object.assign({}, data), { 
                // eslint-disable-next-line @typescript-eslint/naming-convention
                fk_id_usuario: userId, nombreAhorro: data.nombre, tipoAhorro: data.tipo_ahorro }));
        });
    }
    getOne(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            const montos = yield this.http.get(`datosMontos/${id}`).toPromise();
            return this.http.get(`datosAhorro/${id}`).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.map)((result) => (Object.assign(Object.assign({}, result), { montos }))));
        });
    }
    selectIntervalo(data) {
        return this.http.put(`actualizarMonto`, data);
    }
    addMonto(data) {
        return this.http.post(`agregarMonto`, data);
    }
    delete(idAhorro, tipo) {
        return this.http.delete(`borrarAhorro`, { idAhorro, tipo });
    }
    shareSaving(userId, savingId, remove) {
        return this.http.post('compartirAhorro', { userId, savingId, remove });
    }
    getSharedSavingsUsers(ahorroId) {
        return this.http.get(`listarUsuariosCompartidos/${ahorroId}`);
    }
};
AhorrosService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_1__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_2__.StorageService }
];
AhorrosService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], AhorrosService);



/***/ }),

/***/ 30407:
/*!**********************************************!*\
  !*** ./src/app/services/contacts.service.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ContactsService": () => (/* binding */ ContactsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _http_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./http.service */ 6858);
/* harmony import */ var _storage_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./storage.service */ 71188);




let ContactsService = class ContactsService {
    constructor(http, storage) {
        this.http = http;
        this.storage = storage;
    }
    getContacts(userId) {
        return this.http.get(`traerContactos/${userId}`);
    }
    addContact(email) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            const { id: userId } = yield this.storage.get('user');
            return this.http.post(`agregarContacto`, {
                userId,
                email
            });
        });
    }
};
ContactsService.ctorParameters = () => [
    { type: _http_service__WEBPACK_IMPORTED_MODULE_0__.HttpService },
    { type: _storage_service__WEBPACK_IMPORTED_MODULE_1__.StorageService }
];
ContactsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], ContactsService);



/***/ }),

/***/ 98914:
/*!******************************************!*\
  !*** ./src/app/services/menu.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuService": () => (/* binding */ MenuService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ 93819);



let MenuService = class MenuService {
    constructor(menu) {
        this.menu = menu;
    }
    toggle() {
        this.menu.toggle('menu');
    }
};
MenuService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_0__.MenuController }
];
MenuService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], MenuService);



/***/ }),

/***/ 22134:
/*!*********************************!*\
  !*** ./src/app/shared/utils.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Utils": () => (/* binding */ Utils)
/* harmony export */ });
class Utils {
    static getPercentage(currentValue, goal) {
        const porcentaje = (currentValue * 100) / goal;
        const [_, decimal] = String(porcentaje).split('.');
        return decimal ? porcentaje.toFixed(1) : porcentaje;
    }
}


/***/ }),

/***/ 55917:
/*!************************************************************************!*\
  !*** ./src/app/components/calendar/calendar.component.scss?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "ion-datetime {\n  height: 382px;\n  width: auto;\n  max-width: 350px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhbGVuZGFyLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUVBLFdBQUE7RUFFQSxnQkFBQTtBQURKIiwiZmlsZSI6ImNhbGVuZGFyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWRhdGV0aW1lIHtcclxuICAgIGhlaWdodDogMzgycHg7XHJcblxyXG4gICAgd2lkdGg6IGF1dG87XHJcblxyXG4gICAgbWF4LXdpZHRoOiAzNTBweDtcclxuICB9Il19 */";

/***/ }),

/***/ 62905:
/*!****************************************************************************************!*\
  !*** ./src/app/components/contacts-chooser/contacts-chooser.component.scss?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb250YWN0cy1jaG9vc2VyLmNvbXBvbmVudC5zY3NzIn0= */";

/***/ }),

/***/ 75413:
/*!********************************************************************!*\
  !*** ./src/app/components/header/header.component.scss?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = ":host {\n  background-color: #195d9f;\n  border-radius: 0 0 20px 20px;\n}\n:host ion-toolbar {\n  height: 65px;\n  border-radius: 0 0 20px 20px;\n  --background: #195d9f;\n  padding-top: 10px;\n  color: #ffff;\n  border-bottom: 5px solid #6fa1f5;\n}\n:host ion-toolbar ion-icon {\n  color: #ffff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhlYWRlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLHlCQUFBO0VBQ0EsNEJBQUE7QUFBSjtBQUVJO0VBQ0ksWUFBQTtFQUNBLDRCQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxnQ0FBQTtBQUFSO0FBQ1E7RUFDSSxZQUFBO0FBQ1oiLCJmaWxlIjoiaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3R7XHJcbiAgICAvLyBoZWlnaHQ6IDklO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE5NWQ5ZjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgMCAyMHB4IDIwcHg7XHJcblxyXG4gICAgaW9uLXRvb2xiYXJ7XHJcbiAgICAgICAgaGVpZ2h0OiA2NXB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDAgMCAyMHB4IDIwcHg7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjMTk1ZDlmO1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZjtcclxuICAgICAgICBib3JkZXItYm90dG9tOiA1cHggc29saWQgIzZmYTFmNTtcclxuICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgY29sb3I6ICNmZmZmO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuXHJcblxyXG59XHJcblxyXG4iXX0= */";

/***/ }),

/***/ 69253:
/*!************************************************************************!*\
  !*** ./src/app/components/calendar/calendar.component.html?ngResource ***!
  \************************************************************************/
/***/ ((module) => {

module.exports = "<ion-datetime size=\"cover\" (ionChange)=\"selectDate($event)\" clearText=\"Limpiar\" [locale]=\"'es'\" [min]=\"today\" [max]=\"max\" presentation=\"date\" [showClearButton]=\"true\"  ></ion-datetime>";

/***/ }),

/***/ 31068:
/*!****************************************************************************************!*\
  !*** ./src/app/components/contacts-chooser/contacts-chooser.component.html?ngResource ***!
  \****************************************************************************************/
/***/ ((module) => {

module.exports = "<ion-list lines=\"full\">\n  <ion-list-header lines=\"full\">\n    <ion-label>Agregar contacto</ion-label>\n    <ion-button (click)=\"goContacts()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-button>\n  </ion-list-header>\n\n  <ion-item *ngFor=\"let contacto of listaContactos\" (click)=\"selectContact(contacto)\">\n    <ion-label>{{ contacto.nombre | titlecase }}</ion-label>\n    <ion-icon slot=\"end\" [name]=\"isSelected(contacto) ?  'checkbox-outline' : 'square-outline' \"></ion-icon>\n  </ion-item>\n \n</ion-list>";

/***/ }),

/***/ 2011:
/*!********************************************************************!*\
  !*** ./src/app/components/header/header.component.html?ngResource ***!
  \********************************************************************/
/***/ ((module) => {

module.exports = "\r\n<ion-toolbar class=\"ion-text-center\" mode=\"ios\" lines=\"none\">\r\n  <ion-buttons slot=\"start\">\r\n    <ion-button (click)=\"datos?.startFunction ? datos?.startFunction() : menu.toggle()\">\r\n      <ion-icon [name]=\"datos?.startIcon || 'menu-outline'\"></ion-icon>\r\n    </ion-button>\r\n  </ion-buttons>\r\n  <ion-buttons slot=\"end\" *ngIf=\"datos?.endFunction\">\r\n    <ion-button (click)=\"datos?.endFunction()\">\r\n      <ion-icon [name]=\"datos?.endIcon\"></ion-icon>\r\n    </ion-button>\r\n  </ion-buttons>\r\n  <ion-title>{{title}}</ion-title>\r\n</ion-toolbar>";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_folder_module_ts.js.map