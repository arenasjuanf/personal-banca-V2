"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_auth_auth_module_ts"],{

/***/ 40431:
/*!*********************************************!*\
  !*** ./src/app/auth/auth-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthPageRoutingModule": () => (/* binding */ AuthPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _auth_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.page */ 13561);




const routes = [
    {
        path: 'login',
        component: _auth_page__WEBPACK_IMPORTED_MODULE_0__.AuthPage
    },
    {
        path: 'register',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_auth_register_register_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./register/register.module */ 38270)).then(m => m.RegisterPageModule)
    },
    {
        path: 'recover',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_auth_recover-pass_recover-pass_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./recover-pass/recover-pass.module */ 86725)).then(m => m.RecoverPassPageModule)
    },
    {
        path: '**',
        pathMatch: 'full',
        redirectTo: 'login'
    }
];
let AuthPageRoutingModule = class AuthPageRoutingModule {
};
AuthPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AuthPageRoutingModule);



/***/ }),

/***/ 71674:
/*!*************************************!*\
  !*** ./src/app/auth/auth.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthPageModule": () => (/* binding */ AuthPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _auth_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth-routing.module */ 40431);
/* harmony import */ var _auth_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.page */ 13561);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);








let AuthPageModule = class AuthPageModule {
};
AuthPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _auth_routing_module__WEBPACK_IMPORTED_MODULE_0__.AuthPageRoutingModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.ReactiveFormsModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_7__.RxReactiveFormsModule
        ],
        declarations: [_auth_page__WEBPACK_IMPORTED_MODULE_1__.AuthPage]
    })
], AuthPageModule);



/***/ }),

/***/ 13561:
/*!***********************************!*\
  !*** ./src/app/auth/auth.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthPage": () => (/* binding */ AuthPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _auth_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.page.html?ngResource */ 2708);
/* harmony import */ var _auth_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./auth.page.scss?ngResource */ 57783);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _models_login_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../models/login.model */ 25383);
/* harmony import */ var _services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/auth.service */ 37556);
/* harmony import */ var _services_forms_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/forms.service */ 76311);
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/storage.service */ 71188);
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/toast.service */ 84465);










let AuthPage = class AuthPage {
    constructor(router, forms, authService, storage, toast) {
        this.router = router;
        this.forms = forms;
        this.authService = authService;
        this.storage = storage;
        this.toast = toast;
        this.form = this.forms.initForm(new _models_login_model__WEBPACK_IMPORTED_MODULE_2__.LoginModel());
    }
    ngOnInit() {
    }
    goTo(path) {
        this.router.navigateByUrl(path);
    }
    login() {
        if (!this.form.valid) {
            this.form.markAllAsTouched();
            return;
        }
        const { email, password } = this.form.value;
        this.loading = true;
        this.authService.login(email, password).subscribe(({ success, msj }) => (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__awaiter)(this, void 0, void 0, function* () {
            const { pass, pin } = msj, userData = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__rest)(msj, ["pass", "pin"]);
            // eslint-disable-next-line @typescript-eslint/no-unused-expressions
            if (success) {
                yield this.storage.set('user', userData);
                this.loading = false;
                this.router.navigateByUrl('pages/home');
            }
            else {
                this.toast.show({
                    message: msj,
                    icon: 'close',
                    position: 'bottom',
                    duration: 1500
                });
            }
            this.loading = false;
        }));
    }
};
AuthPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__.Router },
    { type: _services_forms_service__WEBPACK_IMPORTED_MODULE_4__.FormsService },
    { type: _services_auth_service__WEBPACK_IMPORTED_MODULE_3__.AuthService },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_5__.StorageService },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_6__.ToastService }
];
AuthPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_9__.Component)({
        selector: 'app-auth',
        template: _auth_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_auth_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AuthPage);



/***/ }),

/***/ 25383:
/*!***************************************!*\
  !*** ./src/app/models/login.model.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginModel": () => (/* binding */ LoginModel)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @rxweb/reactive-form-validators */ 19680);


class LoginModel {
    constructor() {
        this.mantenerSesion = false;
    }
}
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)(),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.email)({ message: 'el campo debe ser un email' }),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], LoginModel.prototype, "email", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)(),
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.required)({ message: 'campo requerido' })
], LoginModel.prototype, "password", void 0);
(0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_rxweb_reactive_form_validators__WEBPACK_IMPORTED_MODULE_1__.prop)()
], LoginModel.prototype, "mantenerSesion", void 0);


/***/ }),

/***/ 57783:
/*!************************************************!*\
  !*** ./src/app/auth/auth.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-grid {\n  font-family: \"Poppins\", sans-serif;\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-grid ion-row {\n  height: auto;\n}\nion-grid ion-row ion-img {\n  width: 75%;\n  margin: auto;\n}\nion-grid ion-row h1 {\n  font-weight: 700;\n  margin: 0 0 10px 0;\n}\nion-grid ion-row .form-cont {\n  background-color: #ffffff8a;\n  border-radius: 25px;\n  border: 3px solid #b5abab40;\n}\nion-grid ion-row ion-col {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-grid ion-row ion-col .input {\n  border-radius: 20px;\n  border: 1px solid #3780ff9e;\n  margin: 0px 0px 10px 0px;\n}\nion-grid ion-row ion-col .mantener-sesion {\n  margin-bottom: 10px;\n}\nion-grid ion-row ion-col .mantener-sesion ion-label {\n  margin-left: 10px;\n}\nion-grid ion-row ion-col .mantener-sesion::part(native) {\n  background-color: transparent;\n}\nion-grid ion-row ion-col .recuperar-clave {\n  margin-top: 10px;\n}\nion-grid ion-row ion-col ion-button {\n  border: 3px solid #b5abab12;\n  width: 60%;\n  margin: auto;\n}\nion-content::part(scroll) {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n}\nion-content::part(background) {\n  background: url('figures2.svg');\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGgucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBRUksa0NBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtBQUZKO0FBS0k7RUFDSSxZQUFBO0FBSFI7QUFLUTtFQUNJLFVBQUE7RUFDQSxZQUFBO0FBSFo7QUFNUTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7QUFKWjtBQVFRO0VBQ0ksMkJBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0FBTlo7QUFTUTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0FBUFo7QUFTWTtFQUNJLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSx3QkFBQTtBQVBoQjtBQVVZO0VBSUksbUJBQUE7QUFYaEI7QUFRZ0I7RUFDSSxpQkFBQTtBQU5wQjtBQVVnQjtFQUNJLDZCQUFBO0FBUnBCO0FBWVk7RUFDSSxnQkFBQTtBQVZoQjtBQWFZO0VBQ0ksMkJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQVhoQjtBQXNCQTtFQUNJLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0FBbkJKO0FBc0JBO0VBQ0csK0JBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0FBbkJIIiwiZmlsZSI6ImF1dGgucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5pb24tZ3JpZHtcclxuXHJcbiAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuIFxyXG5cclxuICAgIGlvbi1yb3d7XHJcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG5cclxuICAgICAgICBpb24taW1ne1xyXG4gICAgICAgICAgICB3aWR0aDogNzUlO1xyXG4gICAgICAgICAgICBtYXJnaW46IGF1dG87XHJcbiAgICAgICAgfVxyXG4gICAgXHJcbiAgICAgICAgaDF7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMCAwIDEwcHggMDtcclxuXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAuZm9ybS1jb250eyAgICAgICBcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjhhO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAyNXB4O1xyXG4gICAgICAgICAgICBib3JkZXI6IDNweCBzb2xpZCAjYjVhYmFiNDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpb24tY29se1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuXHJcbiAgICAgICAgICAgIC5pbnB1dHtcclxuICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjMzc4MGZmOWU7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDBweCAwcHggMTBweCAwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC5tYW50ZW5lci1zZXNpb257XHJcbiAgICAgICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG5cclxuICAgICAgICAgICAgICAgICY6OnBhcnQobmF0aXZlKXtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLnJlY3VwZXJhci1jbGF2ZXtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IDNweCBzb2xpZCAjYjVhYmFiMTI7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDogNjAlO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgfVxyXG5cclxufVxyXG5cclxuXHJcbmlvbi1jb250ZW50OjpwYXJ0KHNjcm9sbCl7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG5pb24tY29udGVudDo6cGFydChiYWNrZ3JvdW5kKXtcclxuICAgYmFja2dyb3VuZDogdXJsKC4uLy4uL2Fzc2V0cy9maWd1cmVzMi5zdmcpO1xyXG4gICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG59XHJcblxyXG5cclxuXHJcblxyXG4iXX0= */";

/***/ }),

/***/ 2708:
/*!************************************************!*\
  !*** ./src/app/auth/auth.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\r\n  <ion-grid class=\"ion-padding\">\r\n    <ion-row>\r\n      \r\n      <ion-col  size-md=\"6\" size-xs=\"12\">\r\n        <ion-img src=\"./assets/icon/logo.svg\" class=\"ion-padding\"></ion-img>\r\n      </ion-col>\r\n\r\n\r\n      <ion-col size-md=\"6\" size-xs=\"12\" class=\"ion-padding form-cont\" [formGroup]=\"form\">\r\n\r\n        <ion-text class=\"ion-text-center\">\r\n          <h1>Iniciar sesión</h1>\r\n        </ion-text>\r\n\r\n        <ion-label >Correo Electrónico</ion-label>\r\n        <ion-item  class=\"input\">\r\n          <ion-input placeholder=\"Correo Electrónico\" formControlName=\"email\"></ion-input>\r\n        </ion-item>\r\n        <ion-text  *ngIf=\"forms.getErrors(form, 'email')?.required\">\r\n          <ion-note color=\"danger\">{{ forms.getErrors(form, 'email').required.message }}</ion-note>\r\n        </ion-text>  \r\n        <ion-text  *ngIf=\"forms.getErrors(form, 'email')?.email\">\r\n          <ion-note color=\"danger\">{{ forms.getErrors(form, 'email').email.message }}</ion-note>\r\n        </ion-text>  \r\n\r\n        <ion-label >Contraseña</ion-label>\r\n        <ion-item  class=\"input\">\r\n          <ion-input placeholder=\"Contraseña\" formControlName=\"password\" type=\"password\"></ion-input>     \r\n        </ion-item>\r\n        <ion-text *ngIf=\"forms.getErrors(form, 'password')?.required\">\r\n          <ion-note  color=\"danger\">{{ forms.getErrors(form, 'password').required.message }}</ion-note>\r\n        </ion-text>     \r\n\r\n        <ion-item  class=\"mantener-sesion\" lines=\"none\">\r\n          <ion-checkbox formControlName=\"mantenerSesion\"></ion-checkbox>\r\n          <ion-label>Mantener sesión</ion-label>\r\n        </ion-item>\r\n\r\n        <ion-button color=\"primary\" class=\"login-button ion-activatable ripple-parent\" shape=\"round\" (click)=\"login()\">\r\n          <ion-icon name=\"enter-outline\" slot=\"start\" *ngIf=\"!loading\" ></ion-icon>\r\n          <ion-spinner name=\"lines\" *ngIf=\"loading\"></ion-spinner>\r\n          {{ loading ? 'Ingresando' : 'Ingresar' }} \r\n          <ion-ripple-effect></ion-ripple-effect>\r\n        </ion-button>\r\n\r\n        <ion-text class=\"ion-text-center recuperar-clave\">\r\n          <small>\r\n            Olvidaste tu contraseña?\r\n            <ion-text color=\"primary\">\r\n              <b class=\"pointer\" (click)=\"goTo('auth/recover')\">Recuperala</b>\r\n            </ion-text>\r\n          </small>\r\n        </ion-text>\r\n        \r\n\r\n        <ion-text class=\"ion-text-center\">\r\n          <p>\r\n            No tienes una cuenta? \r\n            <ion-text color=\"primary\">\r\n              <b class=\"pointer\" (click)=\"goTo('auth/register')\">Registrate</b>\r\n            </ion-text>\r\n          </p>\r\n        </ion-text>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_auth_auth_module_ts.js.map