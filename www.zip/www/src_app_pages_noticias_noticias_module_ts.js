"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_pages_noticias_noticias_module_ts"],{

/***/ 35861:
/*!***********************************************************!*\
  !*** ./src/app/pages/noticias/noticias-routing.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NoticiasPageRoutingModule": () => (/* binding */ NoticiasPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 52816);
/* harmony import */ var _noticias_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./noticias.page */ 40792);




const routes = [
    {
        path: '',
        component: _noticias_page__WEBPACK_IMPORTED_MODULE_0__.NoticiasPage
    }
];
let NoticiasPageRoutingModule = class NoticiasPageRoutingModule {
};
NoticiasPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], NoticiasPageRoutingModule);



/***/ }),

/***/ 59623:
/*!***************************************************!*\
  !*** ./src/app/pages/noticias/noticias.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NoticiasPageModule": () => (/* binding */ NoticiasPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common */ 36362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ 90587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _noticias_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./noticias-routing.module */ 35861);
/* harmony import */ var _noticias_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./noticias.page */ 40792);
/* harmony import */ var src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/components/components.module */ 45642);








let NoticiasPageModule = class NoticiasPageModule {
};
NoticiasPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_5__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_6__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_7__.IonicModule,
            _noticias_routing_module__WEBPACK_IMPORTED_MODULE_0__.NoticiasPageRoutingModule,
            src_app_components_components_module__WEBPACK_IMPORTED_MODULE_2__.ComponentsModule
        ],
        declarations: [_noticias_page__WEBPACK_IMPORTED_MODULE_1__.NoticiasPage],
        providers: []
    })
], NoticiasPageModule);



/***/ }),

/***/ 40792:
/*!*************************************************!*\
  !*** ./src/app/pages/noticias/noticias.page.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NoticiasPage": () => (/* binding */ NoticiasPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _noticias_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./noticias.page.html?ngResource */ 65599);
/* harmony import */ var _noticias_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./noticias.page.scss?ngResource */ 28434);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @awesome-cordova-plugins/in-app-browser/ngx */ 12407);
/* harmony import */ var src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/loading.service */ 4471);
/* harmony import */ var src_app_services_news_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/services/news.service */ 41857);







let NoticiasPage = class NoticiasPage {
    constructor(newsService, loading, iab) {
        this.newsService = newsService;
        this.loading = loading;
        this.iab = iab;
        this.news = [];
        this.newsService.categoryPage = 0;
        this.traerNoticias();
    }
    ngOnInit() {
    }
    traerNoticias() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            yield this.loading.show('Cargando Noticias');
            this.newsService.getTopHeadLinesCategory().subscribe((result) => {
                this.news = [...this.news, ...result.articles];
                this.loading.hide();
            });
        });
    }
    ver(noticia) {
        this.iab.create(noticia.url);
    }
    errorImage(img) {
        img.src = 'src/assets/images/dolar.jpg';
    }
};
NoticiasPage.ctorParameters = () => [
    { type: src_app_services_news_service__WEBPACK_IMPORTED_MODULE_4__.NewsService },
    { type: src_app_services_loading_service__WEBPACK_IMPORTED_MODULE_3__.LoadingService },
    { type: _awesome_cordova_plugins_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_2__.InAppBrowser }
];
NoticiasPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-noticias',
        template: _noticias_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_noticias_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], NoticiasPage);



/***/ }),

/***/ 41857:
/*!******************************************!*\
  !*** ./src/app/services/news.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NewsService": () => (/* binding */ NewsService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 28784);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! src/environments/environment */ 92340);

/* eslint-disable @typescript-eslint/member-ordering */
/* eslint-disable @typescript-eslint/naming-convention */



let NewsService = class NewsService {
    constructor(http) {
        this.http = http;
        this.KEY = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.newsKey;
        this.URL = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__.environment.newsUrl;
        this.headlinesPage = 0;
        this.categoryPage = 0;
        this.headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpHeaders({
            'x-Api-key': this.KEY,
        });
    }
    query(query) {
        return this.http.get(this.URL + query, { headers: this.headers });
    }
    getTopHeadLinesCategory(category = 'business') {
        this.categoryPage++;
        return this.query(`/top-headlines?language=es&country=co&category=${category}&page=${this.categoryPage}`);
    }
};
NewsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
NewsService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], NewsService);



/***/ }),

/***/ 28434:
/*!**************************************************************!*\
  !*** ./src/app/pages/noticias/noticias.page.scss?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "ion-content::part(background) {\n  border: 2px solid #b9cae833;\n  margin: 4px;\n  border-radius: 20px;\n  background-color: #e3edff33;\n}\n\nion-card {\n  border-radius: 15px;\n  border: 2px solid #6fa1f55c;\n  height: 100%;\n}\n\nion-card ion-card-header {\n  height: 33%;\n}\n\nion-card ion-card-content {\n  height: 33%;\n}\n\nion-card ion-img {\n  height: 33%;\n}\n\nion-card ion-img::part(image) {\n  border-radius: 5px;\n  margin: auto;\n  max-width: 95%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vdGljaWFzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDJCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7QUFDSjs7QUFFQTtFQUNJLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBQ0k7RUFDSSxXQUFBO0FBQ1I7O0FBRUk7RUFDSSxXQUFBO0FBQVI7O0FBR0k7RUFDSSxXQUFBO0FBRFI7O0FBR1E7RUFDSSxrQkFBQTtFQUVBLFlBQUE7RUFDQSxjQUFBO0FBRloiLCJmaWxlIjoibm90aWNpYXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQ6OnBhcnQoYmFja2dyb3VuZCl7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCAjYjljYWU4MzM7XHJcbiAgICBtYXJnaW46IDRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTNlZGZmMzM7XHJcbn1cclxuXHJcbmlvbi1jYXJke1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkICM2ZmExZjU1YztcclxuICAgIGhlaWdodDogMTAwJTtcclxuXHJcbiAgICBpb24tY2FyZC1oZWFkZXJ7XHJcbiAgICAgICAgaGVpZ2h0OiAzMyU7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWNhcmQtY29udGVudHtcclxuICAgICAgICBoZWlnaHQ6IDMzJTtcclxuICAgIH1cclxuXHJcbiAgICBpb24taW1ne1xyXG4gICAgICAgIGhlaWdodDogMzMlO1xyXG5cclxuICAgICAgICAmOjpwYXJ0KGltYWdlKXtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgICAgICAvLyBib3JkZXI6IDJweCBzb2xpZCAjNzE5MmE1NTI7XHJcbiAgICAgICAgICAgIG1hcmdpbjogYXV0bztcclxuICAgICAgICAgICAgbWF4LXdpZHRoOiA5NSU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHJcbn1cclxuIl19 */";

/***/ }),

/***/ 65599:
/*!**************************************************************!*\
  !*** ./src/app/pages/noticias/noticias.page.html?ngResource ***!
  \**************************************************************/
/***/ ((module) => {

module.exports = "<app-header title=\"Noticias\"></app-header>\r\n\r\n<ion-content>\r\n    <ion-grid fixed>\r\n        <ion-row>\r\n            <ion-col size-xs=\"12\" size-md=\"4\" *ngFor=\"let new of news\">\r\n                <ion-card class=\"pointer\" (click)=\"ver(new)\">\r\n                    <ion-card-header>\r\n                        <!-- \r\n                            <ion-card-subtitle>{{ new.title }}</ion-card-subtitle>\r\n                        -->\r\n                        <ion-card-title>{{ new.title }}</ion-card-title>\r\n                    </ion-card-header>\r\n                    \r\n                    <ion-img [src]=\"new.urlToImage\"  (error)=\"errorImage(img)\" #img></ion-img>\r\n                        <ion-card-content>\r\n                        {{ new.description }}\r\n                    </ion-card-content>\r\n                </ion-card>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n</ion-content>\r\n";

/***/ })

}]);
//# sourceMappingURL=src_app_pages_noticias_noticias_module_ts.js.map